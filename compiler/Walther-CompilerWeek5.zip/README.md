README.md

I chose to use Flex and Bison to perform the Scanning and Parsing functions
for my compiler project, respectively. My thought was to get familiar with
these tools for the front-end, while leveraging Boost.Spirit parser/generator
library for the backend of the project. I was astounded by the clunkiness and
confusing design of the Flex and Bison toolset. There appears to be several 
versions of each tool, each somewhat documented, and each maintained by different
individuals. Most of the effort put into this project was experimenting with 
different version of the tools until a simple example would compile/link on 
my computer, given my GCC compiler and C++ requirements. In hindsight, it would
have been much easier to stick with Boost Spirit to perform the entire project.

I have not completed implementation of the symbol table and AST nodes to store the
parsed values. However, the Bison parser does successfully match all the grammar
rules describing the C- language. This is printed in debugging statement to an 
output file: TestOutput.txt

My project was built using GCC 4.8.1 (g++) on Windows 7, obtained from an installation
of MinGW-32. The MinGW 64-bit libraries that allegedly contain Flex and Bison were 
incomplete, and only had one tool. Also, it had to be built from source, which I gave
up on after several hours of effort in attempts to do so. Therefore, I settled with 
pre-built binary versions of Flex (win_flex 2.5.37) and Bison (win_bison 3.0, based 
on GNU Bison 3.0). 

Below is a depiction of how the Flex/Bison grammar files are used to generate a 
C++ executable that reads input from a file and parses it. 

flexScannerSource.l --> Flex --> flexGeneratedScanner.cpp

bisonParserSource.ypp --> Bison --> bisonGeneratedParser.hpp/cpp

flexGeneratedScanner.cpp
bisonGeneratedParser.hpp/cpp  --> GCC --> flexBisonScannerParser.exe

The program can be called as such from the command line to parse the contents 
of the input file (C-Input-1.txt) and save the debugging printout to a file.

flexBisonScannerParser.exe < C-Input-1.txt > TestOutput.txt