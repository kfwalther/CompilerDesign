/* parser/listener/visitor header section */

// Generated from D:/workspace/CompilerDesign/compiler/grammar/TParser.g4 by ANTLR 4.7.1

#pragma once

/* listener preinclude section */

#include "antlr4-runtime.h"
#include "TParser.h"

/* listener postinclude section */

namespace antlrcpptest {

/**
 * This interface defines an abstract listener for a parse tree produced by TParser.
 */
class  TParserListener : public antlr4::tree::ParseTreeListener {
public:
/* listener public declarations/members section */

  virtual void enterProgram(TParser::ProgramContext *ctx) = 0;
  virtual void exitProgram(TParser::ProgramContext *ctx) = 0;

  virtual void enterDeclarationList(TParser::DeclarationListContext *ctx) = 0;
  virtual void exitDeclarationList(TParser::DeclarationListContext *ctx) = 0;

  virtual void enterDeclaration(TParser::DeclarationContext *ctx) = 0;
  virtual void exitDeclaration(TParser::DeclarationContext *ctx) = 0;

  virtual void enterVarDeclaration(TParser::VarDeclarationContext *ctx) = 0;
  virtual void exitVarDeclaration(TParser::VarDeclarationContext *ctx) = 0;

  virtual void enterTypeSpecifier(TParser::TypeSpecifierContext *ctx) = 0;
  virtual void exitTypeSpecifier(TParser::TypeSpecifierContext *ctx) = 0;

  virtual void enterFunDeclaration(TParser::FunDeclarationContext *ctx) = 0;
  virtual void exitFunDeclaration(TParser::FunDeclarationContext *ctx) = 0;

  virtual void enterParams(TParser::ParamsContext *ctx) = 0;
  virtual void exitParams(TParser::ParamsContext *ctx) = 0;

  virtual void enterParamList(TParser::ParamListContext *ctx) = 0;
  virtual void exitParamList(TParser::ParamListContext *ctx) = 0;

  virtual void enterParam(TParser::ParamContext *ctx) = 0;
  virtual void exitParam(TParser::ParamContext *ctx) = 0;

  virtual void enterCompoundStmt(TParser::CompoundStmtContext *ctx) = 0;
  virtual void exitCompoundStmt(TParser::CompoundStmtContext *ctx) = 0;

  virtual void enterLocalDeclaration(TParser::LocalDeclarationContext *ctx) = 0;
  virtual void exitLocalDeclaration(TParser::LocalDeclarationContext *ctx) = 0;

  virtual void enterStatementList(TParser::StatementListContext *ctx) = 0;
  virtual void exitStatementList(TParser::StatementListContext *ctx) = 0;

  virtual void enterStatement(TParser::StatementContext *ctx) = 0;
  virtual void exitStatement(TParser::StatementContext *ctx) = 0;

  virtual void enterExpressionStmt(TParser::ExpressionStmtContext *ctx) = 0;
  virtual void exitExpressionStmt(TParser::ExpressionStmtContext *ctx) = 0;

  virtual void enterSelectionStmt(TParser::SelectionStmtContext *ctx) = 0;
  virtual void exitSelectionStmt(TParser::SelectionStmtContext *ctx) = 0;

  virtual void enterIterationStmt(TParser::IterationStmtContext *ctx) = 0;
  virtual void exitIterationStmt(TParser::IterationStmtContext *ctx) = 0;

  virtual void enterReturnStmt(TParser::ReturnStmtContext *ctx) = 0;
  virtual void exitReturnStmt(TParser::ReturnStmtContext *ctx) = 0;

  virtual void enterExpression(TParser::ExpressionContext *ctx) = 0;
  virtual void exitExpression(TParser::ExpressionContext *ctx) = 0;

  virtual void enterVar(TParser::VarContext *ctx) = 0;
  virtual void exitVar(TParser::VarContext *ctx) = 0;

  virtual void enterSimpleExpression(TParser::SimpleExpressionContext *ctx) = 0;
  virtual void exitSimpleExpression(TParser::SimpleExpressionContext *ctx) = 0;

  virtual void enterRelop(TParser::RelopContext *ctx) = 0;
  virtual void exitRelop(TParser::RelopContext *ctx) = 0;

  virtual void enterAdditiveExpression(TParser::AdditiveExpressionContext *ctx) = 0;
  virtual void exitAdditiveExpression(TParser::AdditiveExpressionContext *ctx) = 0;

  virtual void enterAddop(TParser::AddopContext *ctx) = 0;
  virtual void exitAddop(TParser::AddopContext *ctx) = 0;

  virtual void enterTerm(TParser::TermContext *ctx) = 0;
  virtual void exitTerm(TParser::TermContext *ctx) = 0;

  virtual void enterMulop(TParser::MulopContext *ctx) = 0;
  virtual void exitMulop(TParser::MulopContext *ctx) = 0;

  virtual void enterFactor(TParser::FactorContext *ctx) = 0;
  virtual void exitFactor(TParser::FactorContext *ctx) = 0;

  virtual void enterCall(TParser::CallContext *ctx) = 0;
  virtual void exitCall(TParser::CallContext *ctx) = 0;

  virtual void enterArgs(TParser::ArgsContext *ctx) = 0;
  virtual void exitArgs(TParser::ArgsContext *ctx) = 0;

  virtual void enterArgList(TParser::ArgListContext *ctx) = 0;
  virtual void exitArgList(TParser::ArgListContext *ctx) = 0;


private:  
/* listener private declarations/members section */
};

}  // namespace antlrcpptest
