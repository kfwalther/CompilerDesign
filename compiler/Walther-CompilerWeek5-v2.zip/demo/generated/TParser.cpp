/* parser/listener/visitor header section */

// Generated from D:/workspace/CompilerDesign/compiler/grammar/TParser.g4 by ANTLR 4.7.1

/* parser precinclude section */

#include "TParserListener.h"
#include "TParserVisitor.h"

#include "TParser.h"


/* parser postinclude section */
#include "SymbolTable.h"
#include "AstTreeNode.h"

#ifndef _WIN32
#pragma GCC diagnostic ignored "-Wunused-parameter"
#endif


using namespace antlrcpp;
using namespace antlrcpptest;
using namespace antlr4;

TParser::TParser(TokenStream *input) : Parser(input) {
  _interpreter = new atn::ParserATNSimulator(this, _atn, _decisionToDFA, _sharedContextCache);
}

TParser::~TParser() {
  delete _interpreter;
}

std::string TParser::getGrammarFileName() const {
  return "TParser.g4";
}

const std::vector<std::string>& TParser::getRuleNames() const {
  return _ruleNames;
}

dfa::Vocabulary& TParser::getVocabulary() const {
  return _vocabulary;
}

/* parser definitions section */

//----------------- ProgramContext ------------------------------------------------------------------

TParser::ProgramContext::ProgramContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

TParser::DeclarationListContext* TParser::ProgramContext::declarationList() {
  return getRuleContext<TParser::DeclarationListContext>(0);
}


size_t TParser::ProgramContext::getRuleIndex() const {
  return TParser::RuleProgram;
}

void TParser::ProgramContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterProgram(this);
}

void TParser::ProgramContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitProgram(this);
}


antlrcpp::Any TParser::ProgramContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TParserVisitor*>(visitor))
    return parserVisitor->visitProgram(this);
  else
    return visitor->visitChildren(this);
}

TParser::ProgramContext* TParser::program() {
  ProgramContext *_localctx = _tracker.createInstance<ProgramContext>(_ctx, getState());
  enterRule(_localctx, 0, TParser::RuleProgram);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(58);
    declarationList(0);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- DeclarationListContext ------------------------------------------------------------------

TParser::DeclarationListContext::DeclarationListContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

TParser::DeclarationContext* TParser::DeclarationListContext::declaration() {
  return getRuleContext<TParser::DeclarationContext>(0);
}

TParser::DeclarationListContext* TParser::DeclarationListContext::declarationList() {
  return getRuleContext<TParser::DeclarationListContext>(0);
}


size_t TParser::DeclarationListContext::getRuleIndex() const {
  return TParser::RuleDeclarationList;
}

void TParser::DeclarationListContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterDeclarationList(this);
}

void TParser::DeclarationListContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitDeclarationList(this);
}


antlrcpp::Any TParser::DeclarationListContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TParserVisitor*>(visitor))
    return parserVisitor->visitDeclarationList(this);
  else
    return visitor->visitChildren(this);
}


TParser::DeclarationListContext* TParser::declarationList() {
   return declarationList(0);
}

TParser::DeclarationListContext* TParser::declarationList(int precedence) {
  ParserRuleContext *parentContext = _ctx;
  size_t parentState = getState();
  TParser::DeclarationListContext *_localctx = _tracker.createInstance<DeclarationListContext>(_ctx, parentState);
  TParser::DeclarationListContext *previousContext = _localctx;
  size_t startState = 2;
  enterRecursionRule(_localctx, 2, TParser::RuleDeclarationList, precedence);

    

  auto onExit = finally([=] {
    unrollRecursionContexts(parentContext);
  });
  try {
    size_t alt;
    enterOuterAlt(_localctx, 1);
    setState(61);
    declaration();
    _ctx->stop = _input->LT(-1);
    setState(67);
    _errHandler->sync(this);
    alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 0, _ctx);
    while (alt != 2 && alt != atn::ATN::INVALID_ALT_NUMBER) {
      if (alt == 1) {
        if (!_parseListeners.empty())
          triggerExitRuleEvent();
        previousContext = _localctx;
        _localctx = _tracker.createInstance<DeclarationListContext>(parentContext, parentState);
        pushNewRecursionContext(_localctx, startState, RuleDeclarationList);
        setState(63);

        if (!(precpred(_ctx, 2))) throw FailedPredicateException(this, "precpred(_ctx, 2)");
        setState(64);
        declaration(); 
      }
      setState(69);
      _errHandler->sync(this);
      alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 0, _ctx);
    }
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }
  return _localctx;
}

//----------------- DeclarationContext ------------------------------------------------------------------

TParser::DeclarationContext::DeclarationContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

TParser::VarDeclarationContext* TParser::DeclarationContext::varDeclaration() {
  return getRuleContext<TParser::VarDeclarationContext>(0);
}

TParser::FunDeclarationContext* TParser::DeclarationContext::funDeclaration() {
  return getRuleContext<TParser::FunDeclarationContext>(0);
}


size_t TParser::DeclarationContext::getRuleIndex() const {
  return TParser::RuleDeclaration;
}

void TParser::DeclarationContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterDeclaration(this);
}

void TParser::DeclarationContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitDeclaration(this);
}


antlrcpp::Any TParser::DeclarationContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TParserVisitor*>(visitor))
    return parserVisitor->visitDeclaration(this);
  else
    return visitor->visitChildren(this);
}

TParser::DeclarationContext* TParser::declaration() {
  DeclarationContext *_localctx = _tracker.createInstance<DeclarationContext>(_ctx, getState());
  enterRule(_localctx, 4, TParser::RuleDeclaration);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(72);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 1, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(70);
      varDeclaration();
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(71);
      funDeclaration();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- VarDeclarationContext ------------------------------------------------------------------

TParser::VarDeclarationContext::VarDeclarationContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

TParser::TypeSpecifierContext* TParser::VarDeclarationContext::typeSpecifier() {
  return getRuleContext<TParser::TypeSpecifierContext>(0);
}

tree::TerminalNode* TParser::VarDeclarationContext::ID() {
  return getToken(TParser::ID, 0);
}

tree::TerminalNode* TParser::VarDeclarationContext::SEMICOLON() {
  return getToken(TParser::SEMICOLON, 0);
}

tree::TerminalNode* TParser::VarDeclarationContext::LEFT_BRACKET() {
  return getToken(TParser::LEFT_BRACKET, 0);
}

tree::TerminalNode* TParser::VarDeclarationContext::NUM() {
  return getToken(TParser::NUM, 0);
}

tree::TerminalNode* TParser::VarDeclarationContext::RIGHT_BRACKET() {
  return getToken(TParser::RIGHT_BRACKET, 0);
}


size_t TParser::VarDeclarationContext::getRuleIndex() const {
  return TParser::RuleVarDeclaration;
}

void TParser::VarDeclarationContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterVarDeclaration(this);
}

void TParser::VarDeclarationContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitVarDeclaration(this);
}


antlrcpp::Any TParser::VarDeclarationContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TParserVisitor*>(visitor))
    return parserVisitor->visitVarDeclaration(this);
  else
    return visitor->visitChildren(this);
}

TParser::VarDeclarationContext* TParser::varDeclaration() {
  VarDeclarationContext *_localctx = _tracker.createInstance<VarDeclarationContext>(_ctx, getState());
  enterRule(_localctx, 6, TParser::RuleVarDeclaration);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(85);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 2, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(74);
      typeSpecifier();
      setState(75);
      match(TParser::ID);
      setState(76);
      match(TParser::SEMICOLON);
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(78);
      typeSpecifier();
      setState(79);
      match(TParser::ID);
      setState(80);
      match(TParser::LEFT_BRACKET);
      setState(81);
      match(TParser::NUM);
      setState(82);
      match(TParser::RIGHT_BRACKET);
      setState(83);
      match(TParser::SEMICOLON);
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- TypeSpecifierContext ------------------------------------------------------------------

TParser::TypeSpecifierContext::TypeSpecifierContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* TParser::TypeSpecifierContext::INT_KEYWORD() {
  return getToken(TParser::INT_KEYWORD, 0);
}

tree::TerminalNode* TParser::TypeSpecifierContext::VOID_KEYWORD() {
  return getToken(TParser::VOID_KEYWORD, 0);
}


size_t TParser::TypeSpecifierContext::getRuleIndex() const {
  return TParser::RuleTypeSpecifier;
}

void TParser::TypeSpecifierContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterTypeSpecifier(this);
}

void TParser::TypeSpecifierContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitTypeSpecifier(this);
}


antlrcpp::Any TParser::TypeSpecifierContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TParserVisitor*>(visitor))
    return parserVisitor->visitTypeSpecifier(this);
  else
    return visitor->visitChildren(this);
}

TParser::TypeSpecifierContext* TParser::typeSpecifier() {
  TypeSpecifierContext *_localctx = _tracker.createInstance<TypeSpecifierContext>(_ctx, getState());
  enterRule(_localctx, 8, TParser::RuleTypeSpecifier);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(87);
    _la = _input->LA(1);
    if (!(_la == TParser::INT_KEYWORD

    || _la == TParser::VOID_KEYWORD)) {
    _errHandler->recoverInline(this);
    }
    else {
      _errHandler->reportMatch(this);
      consume();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- FunDeclarationContext ------------------------------------------------------------------

TParser::FunDeclarationContext::FunDeclarationContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

TParser::TypeSpecifierContext* TParser::FunDeclarationContext::typeSpecifier() {
  return getRuleContext<TParser::TypeSpecifierContext>(0);
}

tree::TerminalNode* TParser::FunDeclarationContext::ID() {
  return getToken(TParser::ID, 0);
}

tree::TerminalNode* TParser::FunDeclarationContext::LEFT_PAREN() {
  return getToken(TParser::LEFT_PAREN, 0);
}

TParser::ParamsContext* TParser::FunDeclarationContext::params() {
  return getRuleContext<TParser::ParamsContext>(0);
}

tree::TerminalNode* TParser::FunDeclarationContext::RIGHT_PAREN() {
  return getToken(TParser::RIGHT_PAREN, 0);
}

TParser::CompoundStmtContext* TParser::FunDeclarationContext::compoundStmt() {
  return getRuleContext<TParser::CompoundStmtContext>(0);
}


size_t TParser::FunDeclarationContext::getRuleIndex() const {
  return TParser::RuleFunDeclaration;
}

void TParser::FunDeclarationContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterFunDeclaration(this);
}

void TParser::FunDeclarationContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitFunDeclaration(this);
}


antlrcpp::Any TParser::FunDeclarationContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TParserVisitor*>(visitor))
    return parserVisitor->visitFunDeclaration(this);
  else
    return visitor->visitChildren(this);
}

TParser::FunDeclarationContext* TParser::funDeclaration() {
  FunDeclarationContext *_localctx = _tracker.createInstance<FunDeclarationContext>(_ctx, getState());
  enterRule(_localctx, 10, TParser::RuleFunDeclaration);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(89);
    typeSpecifier();
    setState(90);
    match(TParser::ID);
    setState(91);
    match(TParser::LEFT_PAREN);
    setState(92);
    params();
    setState(93);
    match(TParser::RIGHT_PAREN);
    setState(94);
    compoundStmt();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ParamsContext ------------------------------------------------------------------

TParser::ParamsContext::ParamsContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

TParser::ParamListContext* TParser::ParamsContext::paramList() {
  return getRuleContext<TParser::ParamListContext>(0);
}

tree::TerminalNode* TParser::ParamsContext::VOID_KEYWORD() {
  return getToken(TParser::VOID_KEYWORD, 0);
}


size_t TParser::ParamsContext::getRuleIndex() const {
  return TParser::RuleParams;
}

void TParser::ParamsContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterParams(this);
}

void TParser::ParamsContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitParams(this);
}


antlrcpp::Any TParser::ParamsContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TParserVisitor*>(visitor))
    return parserVisitor->visitParams(this);
  else
    return visitor->visitChildren(this);
}

TParser::ParamsContext* TParser::params() {
  ParamsContext *_localctx = _tracker.createInstance<ParamsContext>(_ctx, getState());
  enterRule(_localctx, 12, TParser::RuleParams);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(98);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 3, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(96);
      paramList(0);
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(97);
      match(TParser::VOID_KEYWORD);
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ParamListContext ------------------------------------------------------------------

TParser::ParamListContext::ParamListContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

TParser::ParamContext* TParser::ParamListContext::param() {
  return getRuleContext<TParser::ParamContext>(0);
}

TParser::ParamListContext* TParser::ParamListContext::paramList() {
  return getRuleContext<TParser::ParamListContext>(0);
}

tree::TerminalNode* TParser::ParamListContext::COMMA() {
  return getToken(TParser::COMMA, 0);
}


size_t TParser::ParamListContext::getRuleIndex() const {
  return TParser::RuleParamList;
}

void TParser::ParamListContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterParamList(this);
}

void TParser::ParamListContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitParamList(this);
}


antlrcpp::Any TParser::ParamListContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TParserVisitor*>(visitor))
    return parserVisitor->visitParamList(this);
  else
    return visitor->visitChildren(this);
}


TParser::ParamListContext* TParser::paramList() {
   return paramList(0);
}

TParser::ParamListContext* TParser::paramList(int precedence) {
  ParserRuleContext *parentContext = _ctx;
  size_t parentState = getState();
  TParser::ParamListContext *_localctx = _tracker.createInstance<ParamListContext>(_ctx, parentState);
  TParser::ParamListContext *previousContext = _localctx;
  size_t startState = 14;
  enterRecursionRule(_localctx, 14, TParser::RuleParamList, precedence);

    

  auto onExit = finally([=] {
    unrollRecursionContexts(parentContext);
  });
  try {
    size_t alt;
    enterOuterAlt(_localctx, 1);
    setState(101);
    param();
    _ctx->stop = _input->LT(-1);
    setState(108);
    _errHandler->sync(this);
    alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 4, _ctx);
    while (alt != 2 && alt != atn::ATN::INVALID_ALT_NUMBER) {
      if (alt == 1) {
        if (!_parseListeners.empty())
          triggerExitRuleEvent();
        previousContext = _localctx;
        _localctx = _tracker.createInstance<ParamListContext>(parentContext, parentState);
        pushNewRecursionContext(_localctx, startState, RuleParamList);
        setState(103);

        if (!(precpred(_ctx, 2))) throw FailedPredicateException(this, "precpred(_ctx, 2)");
        setState(104);
        match(TParser::COMMA);
        setState(105);
        param(); 
      }
      setState(110);
      _errHandler->sync(this);
      alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 4, _ctx);
    }
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }
  return _localctx;
}

//----------------- ParamContext ------------------------------------------------------------------

TParser::ParamContext::ParamContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

TParser::TypeSpecifierContext* TParser::ParamContext::typeSpecifier() {
  return getRuleContext<TParser::TypeSpecifierContext>(0);
}

tree::TerminalNode* TParser::ParamContext::ID() {
  return getToken(TParser::ID, 0);
}

tree::TerminalNode* TParser::ParamContext::LEFT_BRACKET() {
  return getToken(TParser::LEFT_BRACKET, 0);
}

tree::TerminalNode* TParser::ParamContext::RIGHT_BRACKET() {
  return getToken(TParser::RIGHT_BRACKET, 0);
}


size_t TParser::ParamContext::getRuleIndex() const {
  return TParser::RuleParam;
}

void TParser::ParamContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterParam(this);
}

void TParser::ParamContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitParam(this);
}


antlrcpp::Any TParser::ParamContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TParserVisitor*>(visitor))
    return parserVisitor->visitParam(this);
  else
    return visitor->visitChildren(this);
}

TParser::ParamContext* TParser::param() {
  ParamContext *_localctx = _tracker.createInstance<ParamContext>(_ctx, getState());
  enterRule(_localctx, 16, TParser::RuleParam);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(119);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 5, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(111);
      typeSpecifier();
      setState(112);
      match(TParser::ID);
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(114);
      typeSpecifier();
      setState(115);
      match(TParser::ID);
      setState(116);
      match(TParser::LEFT_BRACKET);
      setState(117);
      match(TParser::RIGHT_BRACKET);
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- CompoundStmtContext ------------------------------------------------------------------

TParser::CompoundStmtContext::CompoundStmtContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* TParser::CompoundStmtContext::LEFT_BRACES() {
  return getToken(TParser::LEFT_BRACES, 0);
}

TParser::LocalDeclarationContext* TParser::CompoundStmtContext::localDeclaration() {
  return getRuleContext<TParser::LocalDeclarationContext>(0);
}

TParser::StatementListContext* TParser::CompoundStmtContext::statementList() {
  return getRuleContext<TParser::StatementListContext>(0);
}

tree::TerminalNode* TParser::CompoundStmtContext::RIGHT_BRACES() {
  return getToken(TParser::RIGHT_BRACES, 0);
}


size_t TParser::CompoundStmtContext::getRuleIndex() const {
  return TParser::RuleCompoundStmt;
}

void TParser::CompoundStmtContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterCompoundStmt(this);
}

void TParser::CompoundStmtContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitCompoundStmt(this);
}


antlrcpp::Any TParser::CompoundStmtContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TParserVisitor*>(visitor))
    return parserVisitor->visitCompoundStmt(this);
  else
    return visitor->visitChildren(this);
}

TParser::CompoundStmtContext* TParser::compoundStmt() {
  CompoundStmtContext *_localctx = _tracker.createInstance<CompoundStmtContext>(_ctx, getState());
  enterRule(_localctx, 18, TParser::RuleCompoundStmt);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(121);
    match(TParser::LEFT_BRACES);
    setState(122);
    localDeclaration(0);
    setState(123);
    statementList(0);
    setState(124);
    match(TParser::RIGHT_BRACES);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- LocalDeclarationContext ------------------------------------------------------------------

TParser::LocalDeclarationContext::LocalDeclarationContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

TParser::LocalDeclarationContext* TParser::LocalDeclarationContext::localDeclaration() {
  return getRuleContext<TParser::LocalDeclarationContext>(0);
}

TParser::VarDeclarationContext* TParser::LocalDeclarationContext::varDeclaration() {
  return getRuleContext<TParser::VarDeclarationContext>(0);
}


size_t TParser::LocalDeclarationContext::getRuleIndex() const {
  return TParser::RuleLocalDeclaration;
}

void TParser::LocalDeclarationContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterLocalDeclaration(this);
}

void TParser::LocalDeclarationContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitLocalDeclaration(this);
}


antlrcpp::Any TParser::LocalDeclarationContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TParserVisitor*>(visitor))
    return parserVisitor->visitLocalDeclaration(this);
  else
    return visitor->visitChildren(this);
}


TParser::LocalDeclarationContext* TParser::localDeclaration() {
   return localDeclaration(0);
}

TParser::LocalDeclarationContext* TParser::localDeclaration(int precedence) {
  ParserRuleContext *parentContext = _ctx;
  size_t parentState = getState();
  TParser::LocalDeclarationContext *_localctx = _tracker.createInstance<LocalDeclarationContext>(_ctx, parentState);
  TParser::LocalDeclarationContext *previousContext = _localctx;
  size_t startState = 20;
  enterRecursionRule(_localctx, 20, TParser::RuleLocalDeclaration, precedence);

    

  auto onExit = finally([=] {
    unrollRecursionContexts(parentContext);
  });
  try {
    size_t alt;
    enterOuterAlt(_localctx, 1);
    _ctx->stop = _input->LT(-1);
    setState(131);
    _errHandler->sync(this);
    alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 6, _ctx);
    while (alt != 2 && alt != atn::ATN::INVALID_ALT_NUMBER) {
      if (alt == 1) {
        if (!_parseListeners.empty())
          triggerExitRuleEvent();
        previousContext = _localctx;
        _localctx = _tracker.createInstance<LocalDeclarationContext>(parentContext, parentState);
        pushNewRecursionContext(_localctx, startState, RuleLocalDeclaration);
        setState(127);

        if (!(precpred(_ctx, 2))) throw FailedPredicateException(this, "precpred(_ctx, 2)");
        setState(128);
        varDeclaration(); 
      }
      setState(133);
      _errHandler->sync(this);
      alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 6, _ctx);
    }
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }
  return _localctx;
}

//----------------- StatementListContext ------------------------------------------------------------------

TParser::StatementListContext::StatementListContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

TParser::StatementListContext* TParser::StatementListContext::statementList() {
  return getRuleContext<TParser::StatementListContext>(0);
}

TParser::StatementContext* TParser::StatementListContext::statement() {
  return getRuleContext<TParser::StatementContext>(0);
}


size_t TParser::StatementListContext::getRuleIndex() const {
  return TParser::RuleStatementList;
}

void TParser::StatementListContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterStatementList(this);
}

void TParser::StatementListContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitStatementList(this);
}


antlrcpp::Any TParser::StatementListContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TParserVisitor*>(visitor))
    return parserVisitor->visitStatementList(this);
  else
    return visitor->visitChildren(this);
}


TParser::StatementListContext* TParser::statementList() {
   return statementList(0);
}

TParser::StatementListContext* TParser::statementList(int precedence) {
  ParserRuleContext *parentContext = _ctx;
  size_t parentState = getState();
  TParser::StatementListContext *_localctx = _tracker.createInstance<StatementListContext>(_ctx, parentState);
  TParser::StatementListContext *previousContext = _localctx;
  size_t startState = 22;
  enterRecursionRule(_localctx, 22, TParser::RuleStatementList, precedence);

    

  auto onExit = finally([=] {
    unrollRecursionContexts(parentContext);
  });
  try {
    size_t alt;
    enterOuterAlt(_localctx, 1);
    _ctx->stop = _input->LT(-1);
    setState(139);
    _errHandler->sync(this);
    alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 7, _ctx);
    while (alt != 2 && alt != atn::ATN::INVALID_ALT_NUMBER) {
      if (alt == 1) {
        if (!_parseListeners.empty())
          triggerExitRuleEvent();
        previousContext = _localctx;
        _localctx = _tracker.createInstance<StatementListContext>(parentContext, parentState);
        pushNewRecursionContext(_localctx, startState, RuleStatementList);
        setState(135);

        if (!(precpred(_ctx, 2))) throw FailedPredicateException(this, "precpred(_ctx, 2)");
        setState(136);
        statement(); 
      }
      setState(141);
      _errHandler->sync(this);
      alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 7, _ctx);
    }
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }
  return _localctx;
}

//----------------- StatementContext ------------------------------------------------------------------

TParser::StatementContext::StatementContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

TParser::ExpressionStmtContext* TParser::StatementContext::expressionStmt() {
  return getRuleContext<TParser::ExpressionStmtContext>(0);
}

TParser::CompoundStmtContext* TParser::StatementContext::compoundStmt() {
  return getRuleContext<TParser::CompoundStmtContext>(0);
}

TParser::SelectionStmtContext* TParser::StatementContext::selectionStmt() {
  return getRuleContext<TParser::SelectionStmtContext>(0);
}

TParser::IterationStmtContext* TParser::StatementContext::iterationStmt() {
  return getRuleContext<TParser::IterationStmtContext>(0);
}

TParser::ReturnStmtContext* TParser::StatementContext::returnStmt() {
  return getRuleContext<TParser::ReturnStmtContext>(0);
}


size_t TParser::StatementContext::getRuleIndex() const {
  return TParser::RuleStatement;
}

void TParser::StatementContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterStatement(this);
}

void TParser::StatementContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitStatement(this);
}


antlrcpp::Any TParser::StatementContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TParserVisitor*>(visitor))
    return parserVisitor->visitStatement(this);
  else
    return visitor->visitChildren(this);
}

TParser::StatementContext* TParser::statement() {
  StatementContext *_localctx = _tracker.createInstance<StatementContext>(_ctx, getState());
  enterRule(_localctx, 24, TParser::RuleStatement);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(147);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case TParser::NUM:
      case TParser::ID:
      case TParser::LEFT_PAREN:
      case TParser::SEMICOLON: {
        enterOuterAlt(_localctx, 1);
        setState(142);
        expressionStmt();
        break;
      }

      case TParser::LEFT_BRACES: {
        enterOuterAlt(_localctx, 2);
        setState(143);
        compoundStmt();
        break;
      }

      case TParser::IF_KEYWORD: {
        enterOuterAlt(_localctx, 3);
        setState(144);
        selectionStmt();
        break;
      }

      case TParser::WHILE_KEYWORD: {
        enterOuterAlt(_localctx, 4);
        setState(145);
        iterationStmt();
        break;
      }

      case TParser::RETURN_KEYWORD: {
        enterOuterAlt(_localctx, 5);
        setState(146);
        returnStmt();
        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ExpressionStmtContext ------------------------------------------------------------------

TParser::ExpressionStmtContext::ExpressionStmtContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

TParser::ExpressionContext* TParser::ExpressionStmtContext::expression() {
  return getRuleContext<TParser::ExpressionContext>(0);
}

tree::TerminalNode* TParser::ExpressionStmtContext::SEMICOLON() {
  return getToken(TParser::SEMICOLON, 0);
}


size_t TParser::ExpressionStmtContext::getRuleIndex() const {
  return TParser::RuleExpressionStmt;
}

void TParser::ExpressionStmtContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterExpressionStmt(this);
}

void TParser::ExpressionStmtContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitExpressionStmt(this);
}


antlrcpp::Any TParser::ExpressionStmtContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TParserVisitor*>(visitor))
    return parserVisitor->visitExpressionStmt(this);
  else
    return visitor->visitChildren(this);
}

TParser::ExpressionStmtContext* TParser::expressionStmt() {
  ExpressionStmtContext *_localctx = _tracker.createInstance<ExpressionStmtContext>(_ctx, getState());
  enterRule(_localctx, 26, TParser::RuleExpressionStmt);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(153);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case TParser::NUM:
      case TParser::ID:
      case TParser::LEFT_PAREN: {
        enterOuterAlt(_localctx, 1);
        setState(149);
        expression();
        setState(150);
        match(TParser::SEMICOLON);
        break;
      }

      case TParser::SEMICOLON: {
        enterOuterAlt(_localctx, 2);
        setState(152);
        match(TParser::SEMICOLON);
        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- SelectionStmtContext ------------------------------------------------------------------

TParser::SelectionStmtContext::SelectionStmtContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* TParser::SelectionStmtContext::IF_KEYWORD() {
  return getToken(TParser::IF_KEYWORD, 0);
}

tree::TerminalNode* TParser::SelectionStmtContext::LEFT_PAREN() {
  return getToken(TParser::LEFT_PAREN, 0);
}

TParser::ExpressionContext* TParser::SelectionStmtContext::expression() {
  return getRuleContext<TParser::ExpressionContext>(0);
}

tree::TerminalNode* TParser::SelectionStmtContext::RIGHT_PAREN() {
  return getToken(TParser::RIGHT_PAREN, 0);
}

std::vector<TParser::StatementContext *> TParser::SelectionStmtContext::statement() {
  return getRuleContexts<TParser::StatementContext>();
}

TParser::StatementContext* TParser::SelectionStmtContext::statement(size_t i) {
  return getRuleContext<TParser::StatementContext>(i);
}

tree::TerminalNode* TParser::SelectionStmtContext::ELSE_KEYWORD() {
  return getToken(TParser::ELSE_KEYWORD, 0);
}


size_t TParser::SelectionStmtContext::getRuleIndex() const {
  return TParser::RuleSelectionStmt;
}

void TParser::SelectionStmtContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterSelectionStmt(this);
}

void TParser::SelectionStmtContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitSelectionStmt(this);
}


antlrcpp::Any TParser::SelectionStmtContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TParserVisitor*>(visitor))
    return parserVisitor->visitSelectionStmt(this);
  else
    return visitor->visitChildren(this);
}

TParser::SelectionStmtContext* TParser::selectionStmt() {
  SelectionStmtContext *_localctx = _tracker.createInstance<SelectionStmtContext>(_ctx, getState());
  enterRule(_localctx, 28, TParser::RuleSelectionStmt);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(169);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 10, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(155);
      match(TParser::IF_KEYWORD);
      setState(156);
      match(TParser::LEFT_PAREN);
      setState(157);
      expression();
      setState(158);
      match(TParser::RIGHT_PAREN);
      setState(159);
      statement();
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(161);
      match(TParser::IF_KEYWORD);
      setState(162);
      match(TParser::LEFT_PAREN);
      setState(163);
      expression();
      setState(164);
      match(TParser::RIGHT_PAREN);
      setState(165);
      statement();
      setState(166);
      match(TParser::ELSE_KEYWORD);
      setState(167);
      statement();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- IterationStmtContext ------------------------------------------------------------------

TParser::IterationStmtContext::IterationStmtContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* TParser::IterationStmtContext::WHILE_KEYWORD() {
  return getToken(TParser::WHILE_KEYWORD, 0);
}

tree::TerminalNode* TParser::IterationStmtContext::LEFT_PAREN() {
  return getToken(TParser::LEFT_PAREN, 0);
}

TParser::ExpressionContext* TParser::IterationStmtContext::expression() {
  return getRuleContext<TParser::ExpressionContext>(0);
}

tree::TerminalNode* TParser::IterationStmtContext::RIGHT_PAREN() {
  return getToken(TParser::RIGHT_PAREN, 0);
}

TParser::StatementContext* TParser::IterationStmtContext::statement() {
  return getRuleContext<TParser::StatementContext>(0);
}


size_t TParser::IterationStmtContext::getRuleIndex() const {
  return TParser::RuleIterationStmt;
}

void TParser::IterationStmtContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterIterationStmt(this);
}

void TParser::IterationStmtContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitIterationStmt(this);
}


antlrcpp::Any TParser::IterationStmtContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TParserVisitor*>(visitor))
    return parserVisitor->visitIterationStmt(this);
  else
    return visitor->visitChildren(this);
}

TParser::IterationStmtContext* TParser::iterationStmt() {
  IterationStmtContext *_localctx = _tracker.createInstance<IterationStmtContext>(_ctx, getState());
  enterRule(_localctx, 30, TParser::RuleIterationStmt);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(171);
    match(TParser::WHILE_KEYWORD);
    setState(172);
    match(TParser::LEFT_PAREN);
    setState(173);
    expression();
    setState(174);
    match(TParser::RIGHT_PAREN);
    setState(175);
    statement();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ReturnStmtContext ------------------------------------------------------------------

TParser::ReturnStmtContext::ReturnStmtContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* TParser::ReturnStmtContext::RETURN_KEYWORD() {
  return getToken(TParser::RETURN_KEYWORD, 0);
}

tree::TerminalNode* TParser::ReturnStmtContext::SEMICOLON() {
  return getToken(TParser::SEMICOLON, 0);
}

TParser::ExpressionContext* TParser::ReturnStmtContext::expression() {
  return getRuleContext<TParser::ExpressionContext>(0);
}


size_t TParser::ReturnStmtContext::getRuleIndex() const {
  return TParser::RuleReturnStmt;
}

void TParser::ReturnStmtContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterReturnStmt(this);
}

void TParser::ReturnStmtContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitReturnStmt(this);
}


antlrcpp::Any TParser::ReturnStmtContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TParserVisitor*>(visitor))
    return parserVisitor->visitReturnStmt(this);
  else
    return visitor->visitChildren(this);
}

TParser::ReturnStmtContext* TParser::returnStmt() {
  ReturnStmtContext *_localctx = _tracker.createInstance<ReturnStmtContext>(_ctx, getState());
  enterRule(_localctx, 32, TParser::RuleReturnStmt);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(183);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 11, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(177);
      match(TParser::RETURN_KEYWORD);
      setState(178);
      match(TParser::SEMICOLON);
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(179);
      match(TParser::RETURN_KEYWORD);
      setState(180);
      expression();
      setState(181);
      match(TParser::SEMICOLON);
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ExpressionContext ------------------------------------------------------------------

TParser::ExpressionContext::ExpressionContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

TParser::VarContext* TParser::ExpressionContext::var() {
  return getRuleContext<TParser::VarContext>(0);
}

tree::TerminalNode* TParser::ExpressionContext::ASSIGN() {
  return getToken(TParser::ASSIGN, 0);
}

TParser::ExpressionContext* TParser::ExpressionContext::expression() {
  return getRuleContext<TParser::ExpressionContext>(0);
}

TParser::SimpleExpressionContext* TParser::ExpressionContext::simpleExpression() {
  return getRuleContext<TParser::SimpleExpressionContext>(0);
}


size_t TParser::ExpressionContext::getRuleIndex() const {
  return TParser::RuleExpression;
}

void TParser::ExpressionContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterExpression(this);
}

void TParser::ExpressionContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitExpression(this);
}


antlrcpp::Any TParser::ExpressionContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TParserVisitor*>(visitor))
    return parserVisitor->visitExpression(this);
  else
    return visitor->visitChildren(this);
}

TParser::ExpressionContext* TParser::expression() {
  ExpressionContext *_localctx = _tracker.createInstance<ExpressionContext>(_ctx, getState());
  enterRule(_localctx, 34, TParser::RuleExpression);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(190);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 12, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(185);
      var();
      setState(186);
      match(TParser::ASSIGN);
      setState(187);
      expression();
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(189);
      simpleExpression();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- VarContext ------------------------------------------------------------------

TParser::VarContext::VarContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* TParser::VarContext::ID() {
  return getToken(TParser::ID, 0);
}

tree::TerminalNode* TParser::VarContext::LEFT_BRACKET() {
  return getToken(TParser::LEFT_BRACKET, 0);
}

TParser::ExpressionContext* TParser::VarContext::expression() {
  return getRuleContext<TParser::ExpressionContext>(0);
}

tree::TerminalNode* TParser::VarContext::RIGHT_BRACKET() {
  return getToken(TParser::RIGHT_BRACKET, 0);
}


size_t TParser::VarContext::getRuleIndex() const {
  return TParser::RuleVar;
}

void TParser::VarContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterVar(this);
}

void TParser::VarContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitVar(this);
}


antlrcpp::Any TParser::VarContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TParserVisitor*>(visitor))
    return parserVisitor->visitVar(this);
  else
    return visitor->visitChildren(this);
}

TParser::VarContext* TParser::var() {
  VarContext *_localctx = _tracker.createInstance<VarContext>(_ctx, getState());
  enterRule(_localctx, 36, TParser::RuleVar);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(198);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 13, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(192);
      match(TParser::ID);
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(193);
      match(TParser::ID);
      setState(194);
      match(TParser::LEFT_BRACKET);
      setState(195);
      expression();
      setState(196);
      match(TParser::RIGHT_BRACKET);
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- SimpleExpressionContext ------------------------------------------------------------------

TParser::SimpleExpressionContext::SimpleExpressionContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<TParser::AdditiveExpressionContext *> TParser::SimpleExpressionContext::additiveExpression() {
  return getRuleContexts<TParser::AdditiveExpressionContext>();
}

TParser::AdditiveExpressionContext* TParser::SimpleExpressionContext::additiveExpression(size_t i) {
  return getRuleContext<TParser::AdditiveExpressionContext>(i);
}

TParser::RelopContext* TParser::SimpleExpressionContext::relop() {
  return getRuleContext<TParser::RelopContext>(0);
}


size_t TParser::SimpleExpressionContext::getRuleIndex() const {
  return TParser::RuleSimpleExpression;
}

void TParser::SimpleExpressionContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterSimpleExpression(this);
}

void TParser::SimpleExpressionContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitSimpleExpression(this);
}


antlrcpp::Any TParser::SimpleExpressionContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TParserVisitor*>(visitor))
    return parserVisitor->visitSimpleExpression(this);
  else
    return visitor->visitChildren(this);
}

TParser::SimpleExpressionContext* TParser::simpleExpression() {
  SimpleExpressionContext *_localctx = _tracker.createInstance<SimpleExpressionContext>(_ctx, getState());
  enterRule(_localctx, 38, TParser::RuleSimpleExpression);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(205);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 14, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(200);
      additiveExpression(0);
      setState(201);
      relop();
      setState(202);
      additiveExpression(0);
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(204);
      additiveExpression(0);
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- RelopContext ------------------------------------------------------------------

TParser::RelopContext::RelopContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* TParser::RelopContext::LESS_THAN_OR_EQUAL() {
  return getToken(TParser::LESS_THAN_OR_EQUAL, 0);
}

tree::TerminalNode* TParser::RelopContext::GREATER_THAN_OR_EQUAL() {
  return getToken(TParser::GREATER_THAN_OR_EQUAL, 0);
}

tree::TerminalNode* TParser::RelopContext::EQUALITY() {
  return getToken(TParser::EQUALITY, 0);
}

tree::TerminalNode* TParser::RelopContext::NON_EQUALITY() {
  return getToken(TParser::NON_EQUALITY, 0);
}

tree::TerminalNode* TParser::RelopContext::LESS_THAN() {
  return getToken(TParser::LESS_THAN, 0);
}

tree::TerminalNode* TParser::RelopContext::GREATER_THAN() {
  return getToken(TParser::GREATER_THAN, 0);
}


size_t TParser::RelopContext::getRuleIndex() const {
  return TParser::RuleRelop;
}

void TParser::RelopContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterRelop(this);
}

void TParser::RelopContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitRelop(this);
}


antlrcpp::Any TParser::RelopContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TParserVisitor*>(visitor))
    return parserVisitor->visitRelop(this);
  else
    return visitor->visitChildren(this);
}

TParser::RelopContext* TParser::relop() {
  RelopContext *_localctx = _tracker.createInstance<RelopContext>(_ctx, getState());
  enterRule(_localctx, 40, TParser::RuleRelop);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(207);
    _la = _input->LA(1);
    if (!((((_la & ~ 0x3fULL) == 0) &&
      ((1ULL << _la) & ((1ULL << TParser::LESS_THAN)
      | (1ULL << TParser::GREATER_THAN)
      | (1ULL << TParser::LESS_THAN_OR_EQUAL)
      | (1ULL << TParser::GREATER_THAN_OR_EQUAL)
      | (1ULL << TParser::EQUALITY)
      | (1ULL << TParser::NON_EQUALITY))) != 0))) {
    _errHandler->recoverInline(this);
    }
    else {
      _errHandler->reportMatch(this);
      consume();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- AdditiveExpressionContext ------------------------------------------------------------------

TParser::AdditiveExpressionContext::AdditiveExpressionContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

TParser::TermContext* TParser::AdditiveExpressionContext::term() {
  return getRuleContext<TParser::TermContext>(0);
}

TParser::AdditiveExpressionContext* TParser::AdditiveExpressionContext::additiveExpression() {
  return getRuleContext<TParser::AdditiveExpressionContext>(0);
}

TParser::AddopContext* TParser::AdditiveExpressionContext::addop() {
  return getRuleContext<TParser::AddopContext>(0);
}


size_t TParser::AdditiveExpressionContext::getRuleIndex() const {
  return TParser::RuleAdditiveExpression;
}

void TParser::AdditiveExpressionContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAdditiveExpression(this);
}

void TParser::AdditiveExpressionContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAdditiveExpression(this);
}


antlrcpp::Any TParser::AdditiveExpressionContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TParserVisitor*>(visitor))
    return parserVisitor->visitAdditiveExpression(this);
  else
    return visitor->visitChildren(this);
}


TParser::AdditiveExpressionContext* TParser::additiveExpression() {
   return additiveExpression(0);
}

TParser::AdditiveExpressionContext* TParser::additiveExpression(int precedence) {
  ParserRuleContext *parentContext = _ctx;
  size_t parentState = getState();
  TParser::AdditiveExpressionContext *_localctx = _tracker.createInstance<AdditiveExpressionContext>(_ctx, parentState);
  TParser::AdditiveExpressionContext *previousContext = _localctx;
  size_t startState = 42;
  enterRecursionRule(_localctx, 42, TParser::RuleAdditiveExpression, precedence);

    

  auto onExit = finally([=] {
    unrollRecursionContexts(parentContext);
  });
  try {
    size_t alt;
    enterOuterAlt(_localctx, 1);
    setState(210);
    term(0);
    _ctx->stop = _input->LT(-1);
    setState(218);
    _errHandler->sync(this);
    alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 15, _ctx);
    while (alt != 2 && alt != atn::ATN::INVALID_ALT_NUMBER) {
      if (alt == 1) {
        if (!_parseListeners.empty())
          triggerExitRuleEvent();
        previousContext = _localctx;
        _localctx = _tracker.createInstance<AdditiveExpressionContext>(parentContext, parentState);
        pushNewRecursionContext(_localctx, startState, RuleAdditiveExpression);
        setState(212);

        if (!(precpred(_ctx, 2))) throw FailedPredicateException(this, "precpred(_ctx, 2)");
        setState(213);
        addop();
        setState(214);
        term(0); 
      }
      setState(220);
      _errHandler->sync(this);
      alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 15, _ctx);
    }
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }
  return _localctx;
}

//----------------- AddopContext ------------------------------------------------------------------

TParser::AddopContext::AddopContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* TParser::AddopContext::PLUS() {
  return getToken(TParser::PLUS, 0);
}

tree::TerminalNode* TParser::AddopContext::MINUS() {
  return getToken(TParser::MINUS, 0);
}


size_t TParser::AddopContext::getRuleIndex() const {
  return TParser::RuleAddop;
}

void TParser::AddopContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAddop(this);
}

void TParser::AddopContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAddop(this);
}


antlrcpp::Any TParser::AddopContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TParserVisitor*>(visitor))
    return parserVisitor->visitAddop(this);
  else
    return visitor->visitChildren(this);
}

TParser::AddopContext* TParser::addop() {
  AddopContext *_localctx = _tracker.createInstance<AddopContext>(_ctx, getState());
  enterRule(_localctx, 44, TParser::RuleAddop);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(221);
    _la = _input->LA(1);
    if (!(_la == TParser::PLUS

    || _la == TParser::MINUS)) {
    _errHandler->recoverInline(this);
    }
    else {
      _errHandler->reportMatch(this);
      consume();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- TermContext ------------------------------------------------------------------

TParser::TermContext::TermContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

TParser::FactorContext* TParser::TermContext::factor() {
  return getRuleContext<TParser::FactorContext>(0);
}

TParser::TermContext* TParser::TermContext::term() {
  return getRuleContext<TParser::TermContext>(0);
}

TParser::MulopContext* TParser::TermContext::mulop() {
  return getRuleContext<TParser::MulopContext>(0);
}


size_t TParser::TermContext::getRuleIndex() const {
  return TParser::RuleTerm;
}

void TParser::TermContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterTerm(this);
}

void TParser::TermContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitTerm(this);
}


antlrcpp::Any TParser::TermContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TParserVisitor*>(visitor))
    return parserVisitor->visitTerm(this);
  else
    return visitor->visitChildren(this);
}


TParser::TermContext* TParser::term() {
   return term(0);
}

TParser::TermContext* TParser::term(int precedence) {
  ParserRuleContext *parentContext = _ctx;
  size_t parentState = getState();
  TParser::TermContext *_localctx = _tracker.createInstance<TermContext>(_ctx, parentState);
  TParser::TermContext *previousContext = _localctx;
  size_t startState = 46;
  enterRecursionRule(_localctx, 46, TParser::RuleTerm, precedence);

    

  auto onExit = finally([=] {
    unrollRecursionContexts(parentContext);
  });
  try {
    size_t alt;
    enterOuterAlt(_localctx, 1);
    setState(224);
    factor();
    _ctx->stop = _input->LT(-1);
    setState(232);
    _errHandler->sync(this);
    alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 16, _ctx);
    while (alt != 2 && alt != atn::ATN::INVALID_ALT_NUMBER) {
      if (alt == 1) {
        if (!_parseListeners.empty())
          triggerExitRuleEvent();
        previousContext = _localctx;
        _localctx = _tracker.createInstance<TermContext>(parentContext, parentState);
        pushNewRecursionContext(_localctx, startState, RuleTerm);
        setState(226);

        if (!(precpred(_ctx, 2))) throw FailedPredicateException(this, "precpred(_ctx, 2)");
        setState(227);
        mulop();
        setState(228);
        factor(); 
      }
      setState(234);
      _errHandler->sync(this);
      alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 16, _ctx);
    }
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }
  return _localctx;
}

//----------------- MulopContext ------------------------------------------------------------------

TParser::MulopContext::MulopContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* TParser::MulopContext::MULTIPLY() {
  return getToken(TParser::MULTIPLY, 0);
}

tree::TerminalNode* TParser::MulopContext::DIVIDE() {
  return getToken(TParser::DIVIDE, 0);
}


size_t TParser::MulopContext::getRuleIndex() const {
  return TParser::RuleMulop;
}

void TParser::MulopContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterMulop(this);
}

void TParser::MulopContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitMulop(this);
}


antlrcpp::Any TParser::MulopContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TParserVisitor*>(visitor))
    return parserVisitor->visitMulop(this);
  else
    return visitor->visitChildren(this);
}

TParser::MulopContext* TParser::mulop() {
  MulopContext *_localctx = _tracker.createInstance<MulopContext>(_ctx, getState());
  enterRule(_localctx, 48, TParser::RuleMulop);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(235);
    _la = _input->LA(1);
    if (!(_la == TParser::MULTIPLY

    || _la == TParser::DIVIDE)) {
    _errHandler->recoverInline(this);
    }
    else {
      _errHandler->reportMatch(this);
      consume();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- FactorContext ------------------------------------------------------------------

TParser::FactorContext::FactorContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* TParser::FactorContext::LEFT_PAREN() {
  return getToken(TParser::LEFT_PAREN, 0);
}

TParser::ExpressionContext* TParser::FactorContext::expression() {
  return getRuleContext<TParser::ExpressionContext>(0);
}

tree::TerminalNode* TParser::FactorContext::RIGHT_PAREN() {
  return getToken(TParser::RIGHT_PAREN, 0);
}

TParser::VarContext* TParser::FactorContext::var() {
  return getRuleContext<TParser::VarContext>(0);
}

TParser::CallContext* TParser::FactorContext::call() {
  return getRuleContext<TParser::CallContext>(0);
}

tree::TerminalNode* TParser::FactorContext::NUM() {
  return getToken(TParser::NUM, 0);
}


size_t TParser::FactorContext::getRuleIndex() const {
  return TParser::RuleFactor;
}

void TParser::FactorContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterFactor(this);
}

void TParser::FactorContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitFactor(this);
}


antlrcpp::Any TParser::FactorContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TParserVisitor*>(visitor))
    return parserVisitor->visitFactor(this);
  else
    return visitor->visitChildren(this);
}

TParser::FactorContext* TParser::factor() {
  FactorContext *_localctx = _tracker.createInstance<FactorContext>(_ctx, getState());
  enterRule(_localctx, 50, TParser::RuleFactor);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(244);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 17, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(237);
      match(TParser::LEFT_PAREN);
      setState(238);
      expression();
      setState(239);
      match(TParser::RIGHT_PAREN);
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(241);
      var();
      break;
    }

    case 3: {
      enterOuterAlt(_localctx, 3);
      setState(242);
      call();
      break;
    }

    case 4: {
      enterOuterAlt(_localctx, 4);
      setState(243);
      match(TParser::NUM);
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- CallContext ------------------------------------------------------------------

TParser::CallContext::CallContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* TParser::CallContext::ID() {
  return getToken(TParser::ID, 0);
}

tree::TerminalNode* TParser::CallContext::LEFT_PAREN() {
  return getToken(TParser::LEFT_PAREN, 0);
}

TParser::ArgsContext* TParser::CallContext::args() {
  return getRuleContext<TParser::ArgsContext>(0);
}

tree::TerminalNode* TParser::CallContext::RIGHT_PAREN() {
  return getToken(TParser::RIGHT_PAREN, 0);
}


size_t TParser::CallContext::getRuleIndex() const {
  return TParser::RuleCall;
}

void TParser::CallContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterCall(this);
}

void TParser::CallContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitCall(this);
}


antlrcpp::Any TParser::CallContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TParserVisitor*>(visitor))
    return parserVisitor->visitCall(this);
  else
    return visitor->visitChildren(this);
}

TParser::CallContext* TParser::call() {
  CallContext *_localctx = _tracker.createInstance<CallContext>(_ctx, getState());
  enterRule(_localctx, 52, TParser::RuleCall);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(246);
    match(TParser::ID);
    setState(247);
    match(TParser::LEFT_PAREN);
    setState(248);
    args();
    setState(249);
    match(TParser::RIGHT_PAREN);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ArgsContext ------------------------------------------------------------------

TParser::ArgsContext::ArgsContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

TParser::ArgListContext* TParser::ArgsContext::argList() {
  return getRuleContext<TParser::ArgListContext>(0);
}


size_t TParser::ArgsContext::getRuleIndex() const {
  return TParser::RuleArgs;
}

void TParser::ArgsContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterArgs(this);
}

void TParser::ArgsContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitArgs(this);
}


antlrcpp::Any TParser::ArgsContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TParserVisitor*>(visitor))
    return parserVisitor->visitArgs(this);
  else
    return visitor->visitChildren(this);
}

TParser::ArgsContext* TParser::args() {
  ArgsContext *_localctx = _tracker.createInstance<ArgsContext>(_ctx, getState());
  enterRule(_localctx, 54, TParser::RuleArgs);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(253);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case TParser::NUM:
      case TParser::ID:
      case TParser::LEFT_PAREN: {
        enterOuterAlt(_localctx, 1);
        setState(251);
        argList(0);
        break;
      }

      case TParser::RIGHT_PAREN: {
        enterOuterAlt(_localctx, 2);

        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ArgListContext ------------------------------------------------------------------

TParser::ArgListContext::ArgListContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

TParser::ExpressionContext* TParser::ArgListContext::expression() {
  return getRuleContext<TParser::ExpressionContext>(0);
}

TParser::ArgListContext* TParser::ArgListContext::argList() {
  return getRuleContext<TParser::ArgListContext>(0);
}

tree::TerminalNode* TParser::ArgListContext::COMMA() {
  return getToken(TParser::COMMA, 0);
}


size_t TParser::ArgListContext::getRuleIndex() const {
  return TParser::RuleArgList;
}

void TParser::ArgListContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterArgList(this);
}

void TParser::ArgListContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<TParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitArgList(this);
}


antlrcpp::Any TParser::ArgListContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<TParserVisitor*>(visitor))
    return parserVisitor->visitArgList(this);
  else
    return visitor->visitChildren(this);
}


TParser::ArgListContext* TParser::argList() {
   return argList(0);
}

TParser::ArgListContext* TParser::argList(int precedence) {
  ParserRuleContext *parentContext = _ctx;
  size_t parentState = getState();
  TParser::ArgListContext *_localctx = _tracker.createInstance<ArgListContext>(_ctx, parentState);
  TParser::ArgListContext *previousContext = _localctx;
  size_t startState = 56;
  enterRecursionRule(_localctx, 56, TParser::RuleArgList, precedence);

    

  auto onExit = finally([=] {
    unrollRecursionContexts(parentContext);
  });
  try {
    size_t alt;
    enterOuterAlt(_localctx, 1);
    setState(256);
    expression();
    _ctx->stop = _input->LT(-1);
    setState(263);
    _errHandler->sync(this);
    alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 19, _ctx);
    while (alt != 2 && alt != atn::ATN::INVALID_ALT_NUMBER) {
      if (alt == 1) {
        if (!_parseListeners.empty())
          triggerExitRuleEvent();
        previousContext = _localctx;
        _localctx = _tracker.createInstance<ArgListContext>(parentContext, parentState);
        pushNewRecursionContext(_localctx, startState, RuleArgList);
        setState(258);

        if (!(precpred(_ctx, 2))) throw FailedPredicateException(this, "precpred(_ctx, 2)");
        setState(259);
        match(TParser::COMMA);
        setState(260);
        expression(); 
      }
      setState(265);
      _errHandler->sync(this);
      alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 19, _ctx);
    }
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }
  return _localctx;
}

bool TParser::sempred(RuleContext *context, size_t ruleIndex, size_t predicateIndex) {
  switch (ruleIndex) {
    case 1: return declarationListSempred(dynamic_cast<DeclarationListContext *>(context), predicateIndex);
    case 7: return paramListSempred(dynamic_cast<ParamListContext *>(context), predicateIndex);
    case 10: return localDeclarationSempred(dynamic_cast<LocalDeclarationContext *>(context), predicateIndex);
    case 11: return statementListSempred(dynamic_cast<StatementListContext *>(context), predicateIndex);
    case 21: return additiveExpressionSempred(dynamic_cast<AdditiveExpressionContext *>(context), predicateIndex);
    case 23: return termSempred(dynamic_cast<TermContext *>(context), predicateIndex);
    case 28: return argListSempred(dynamic_cast<ArgListContext *>(context), predicateIndex);

  default:
    break;
  }
  return true;
}

bool TParser::declarationListSempred(DeclarationListContext *_localctx, size_t predicateIndex) {
  switch (predicateIndex) {
    case 0: return precpred(_ctx, 2);

  default:
    break;
  }
  return true;
}

bool TParser::paramListSempred(ParamListContext *_localctx, size_t predicateIndex) {
  switch (predicateIndex) {
    case 1: return precpred(_ctx, 2);

  default:
    break;
  }
  return true;
}

bool TParser::localDeclarationSempred(LocalDeclarationContext *_localctx, size_t predicateIndex) {
  switch (predicateIndex) {
    case 2: return precpred(_ctx, 2);

  default:
    break;
  }
  return true;
}

bool TParser::statementListSempred(StatementListContext *_localctx, size_t predicateIndex) {
  switch (predicateIndex) {
    case 3: return precpred(_ctx, 2);

  default:
    break;
  }
  return true;
}

bool TParser::additiveExpressionSempred(AdditiveExpressionContext *_localctx, size_t predicateIndex) {
  switch (predicateIndex) {
    case 4: return precpred(_ctx, 2);

  default:
    break;
  }
  return true;
}

bool TParser::termSempred(TermContext *_localctx, size_t predicateIndex) {
  switch (predicateIndex) {
    case 5: return precpred(_ctx, 2);

  default:
    break;
  }
  return true;
}

bool TParser::argListSempred(ArgListContext *_localctx, size_t predicateIndex) {
  switch (predicateIndex) {
    case 6: return precpred(_ctx, 2);

  default:
    break;
  }
  return true;
}

// Static vars and initialization.
std::vector<dfa::DFA> TParser::_decisionToDFA;
atn::PredictionContextCache TParser::_sharedContextCache;

// We own the ATN which in turn owns the ATN states.
atn::ATN TParser::_atn;
std::vector<uint16_t> TParser::_serializedATN;

std::vector<std::string> TParser::_ruleNames = {
  "program", "declarationList", "declaration", "varDeclaration", "typeSpecifier", 
  "funDeclaration", "params", "paramList", "param", "compoundStmt", "localDeclaration", 
  "statementList", "statement", "expressionStmt", "selectionStmt", "iterationStmt", 
  "returnStmt", "expression", "var", "simpleExpression", "relop", "additiveExpression", 
  "addop", "term", "mulop", "factor", "call", "args", "argList"
};

std::vector<std::string> TParser::_literalNames = {
  "", "", "'int'", "'void'", "'if'", "'else'", "'while'", "'return'", "", 
  "", "", "", "", "", "'='", "'+'", "'-'", "'*'", "'/'", "'<'", "'>'", "'('", 
  "')'", "'{'", "'}'", "'['", "']'", "','", "';'", "'<='", "'>='", "'=='", 
  "'!='"
};

std::vector<std::string> TParser::_symbolicNames = {
  "", "DUMMY", "INT_KEYWORD", "VOID_KEYWORD", "IF_KEYWORD", "ELSE_KEYWORD", 
  "WHILE_KEYWORD", "RETURN_KEYWORD", "NUM", "DIGIT", "ID", "LETTER", "COMMENT", 
  "WS", "ASSIGN", "PLUS", "MINUS", "MULTIPLY", "DIVIDE", "LESS_THAN", "GREATER_THAN", 
  "LEFT_PAREN", "RIGHT_PAREN", "LEFT_BRACES", "RIGHT_BRACES", "LEFT_BRACKET", 
  "RIGHT_BRACKET", "COMMA", "SEMICOLON", "LESS_THAN_OR_EQUAL", "GREATER_THAN_OR_EQUAL", 
  "EQUALITY", "NON_EQUALITY"
};

dfa::Vocabulary TParser::_vocabulary(_literalNames, _symbolicNames);

std::vector<std::string> TParser::_tokenNames;

TParser::Initializer::Initializer() {
	for (size_t i = 0; i < _symbolicNames.size(); ++i) {
		std::string name = _vocabulary.getLiteralName(i);
		if (name.empty()) {
			name = _vocabulary.getSymbolicName(i);
		}

		if (name.empty()) {
			_tokenNames.push_back("<INVALID>");
		} else {
      _tokenNames.push_back(name);
    }
	}

  _serializedATN = {
    0x3, 0x608b, 0xa72a, 0x8133, 0xb9ed, 0x417c, 0x3be7, 0x7786, 0x5964, 
    0x3, 0x22, 0x10d, 0x4, 0x2, 0x9, 0x2, 0x4, 0x3, 0x9, 0x3, 0x4, 0x4, 
    0x9, 0x4, 0x4, 0x5, 0x9, 0x5, 0x4, 0x6, 0x9, 0x6, 0x4, 0x7, 0x9, 0x7, 
    0x4, 0x8, 0x9, 0x8, 0x4, 0x9, 0x9, 0x9, 0x4, 0xa, 0x9, 0xa, 0x4, 0xb, 
    0x9, 0xb, 0x4, 0xc, 0x9, 0xc, 0x4, 0xd, 0x9, 0xd, 0x4, 0xe, 0x9, 0xe, 
    0x4, 0xf, 0x9, 0xf, 0x4, 0x10, 0x9, 0x10, 0x4, 0x11, 0x9, 0x11, 0x4, 
    0x12, 0x9, 0x12, 0x4, 0x13, 0x9, 0x13, 0x4, 0x14, 0x9, 0x14, 0x4, 0x15, 
    0x9, 0x15, 0x4, 0x16, 0x9, 0x16, 0x4, 0x17, 0x9, 0x17, 0x4, 0x18, 0x9, 
    0x18, 0x4, 0x19, 0x9, 0x19, 0x4, 0x1a, 0x9, 0x1a, 0x4, 0x1b, 0x9, 0x1b, 
    0x4, 0x1c, 0x9, 0x1c, 0x4, 0x1d, 0x9, 0x1d, 0x4, 0x1e, 0x9, 0x1e, 0x3, 
    0x2, 0x3, 0x2, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 0x7, 
    0x3, 0x44, 0xa, 0x3, 0xc, 0x3, 0xe, 0x3, 0x47, 0xb, 0x3, 0x3, 0x4, 0x3, 
    0x4, 0x5, 0x4, 0x4b, 0xa, 0x4, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 
    0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 
    0x5, 0x5, 0x58, 0xa, 0x5, 0x3, 0x6, 0x3, 0x6, 0x3, 0x7, 0x3, 0x7, 0x3, 
    0x7, 0x3, 0x7, 0x3, 0x7, 0x3, 0x7, 0x3, 0x7, 0x3, 0x8, 0x3, 0x8, 0x5, 
    0x8, 0x65, 0xa, 0x8, 0x3, 0x9, 0x3, 0x9, 0x3, 0x9, 0x3, 0x9, 0x3, 0x9, 
    0x3, 0x9, 0x7, 0x9, 0x6d, 0xa, 0x9, 0xc, 0x9, 0xe, 0x9, 0x70, 0xb, 0x9, 
    0x3, 0xa, 0x3, 0xa, 0x3, 0xa, 0x3, 0xa, 0x3, 0xa, 0x3, 0xa, 0x3, 0xa, 
    0x3, 0xa, 0x5, 0xa, 0x7a, 0xa, 0xa, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 
    0xb, 0x3, 0xb, 0x3, 0xc, 0x3, 0xc, 0x3, 0xc, 0x7, 0xc, 0x84, 0xa, 0xc, 
    0xc, 0xc, 0xe, 0xc, 0x87, 0xb, 0xc, 0x3, 0xd, 0x3, 0xd, 0x3, 0xd, 0x7, 
    0xd, 0x8c, 0xa, 0xd, 0xc, 0xd, 0xe, 0xd, 0x8f, 0xb, 0xd, 0x3, 0xe, 0x3, 
    0xe, 0x3, 0xe, 0x3, 0xe, 0x3, 0xe, 0x5, 0xe, 0x96, 0xa, 0xe, 0x3, 0xf, 
    0x3, 0xf, 0x3, 0xf, 0x3, 0xf, 0x5, 0xf, 0x9c, 0xa, 0xf, 0x3, 0x10, 0x3, 
    0x10, 0x3, 0x10, 0x3, 0x10, 0x3, 0x10, 0x3, 0x10, 0x3, 0x10, 0x3, 0x10, 
    0x3, 0x10, 0x3, 0x10, 0x3, 0x10, 0x3, 0x10, 0x3, 0x10, 0x3, 0x10, 0x5, 
    0x10, 0xac, 0xa, 0x10, 0x3, 0x11, 0x3, 0x11, 0x3, 0x11, 0x3, 0x11, 0x3, 
    0x11, 0x3, 0x11, 0x3, 0x12, 0x3, 0x12, 0x3, 0x12, 0x3, 0x12, 0x3, 0x12, 
    0x3, 0x12, 0x5, 0x12, 0xba, 0xa, 0x12, 0x3, 0x13, 0x3, 0x13, 0x3, 0x13, 
    0x3, 0x13, 0x3, 0x13, 0x5, 0x13, 0xc1, 0xa, 0x13, 0x3, 0x14, 0x3, 0x14, 
    0x3, 0x14, 0x3, 0x14, 0x3, 0x14, 0x3, 0x14, 0x5, 0x14, 0xc9, 0xa, 0x14, 
    0x3, 0x15, 0x3, 0x15, 0x3, 0x15, 0x3, 0x15, 0x3, 0x15, 0x5, 0x15, 0xd0, 
    0xa, 0x15, 0x3, 0x16, 0x3, 0x16, 0x3, 0x17, 0x3, 0x17, 0x3, 0x17, 0x3, 
    0x17, 0x3, 0x17, 0x3, 0x17, 0x3, 0x17, 0x7, 0x17, 0xdb, 0xa, 0x17, 0xc, 
    0x17, 0xe, 0x17, 0xde, 0xb, 0x17, 0x3, 0x18, 0x3, 0x18, 0x3, 0x19, 0x3, 
    0x19, 0x3, 0x19, 0x3, 0x19, 0x3, 0x19, 0x3, 0x19, 0x3, 0x19, 0x7, 0x19, 
    0xe9, 0xa, 0x19, 0xc, 0x19, 0xe, 0x19, 0xec, 0xb, 0x19, 0x3, 0x1a, 0x3, 
    0x1a, 0x3, 0x1b, 0x3, 0x1b, 0x3, 0x1b, 0x3, 0x1b, 0x3, 0x1b, 0x3, 0x1b, 
    0x3, 0x1b, 0x5, 0x1b, 0xf7, 0xa, 0x1b, 0x3, 0x1c, 0x3, 0x1c, 0x3, 0x1c, 
    0x3, 0x1c, 0x3, 0x1c, 0x3, 0x1d, 0x3, 0x1d, 0x5, 0x1d, 0x100, 0xa, 0x1d, 
    0x3, 0x1e, 0x3, 0x1e, 0x3, 0x1e, 0x3, 0x1e, 0x3, 0x1e, 0x3, 0x1e, 0x7, 
    0x1e, 0x108, 0xa, 0x1e, 0xc, 0x1e, 0xe, 0x1e, 0x10b, 0xb, 0x1e, 0x3, 
    0x1e, 0x2, 0x9, 0x4, 0x10, 0x16, 0x18, 0x2c, 0x30, 0x3a, 0x1f, 0x2, 
    0x4, 0x6, 0x8, 0xa, 0xc, 0xe, 0x10, 0x12, 0x14, 0x16, 0x18, 0x1a, 0x1c, 
    0x1e, 0x20, 0x22, 0x24, 0x26, 0x28, 0x2a, 0x2c, 0x2e, 0x30, 0x32, 0x34, 
    0x36, 0x38, 0x3a, 0x2, 0x6, 0x3, 0x2, 0x4, 0x5, 0x4, 0x2, 0x15, 0x16, 
    0x1f, 0x22, 0x3, 0x2, 0x11, 0x12, 0x3, 0x2, 0x13, 0x14, 0x2, 0x108, 
    0x2, 0x3c, 0x3, 0x2, 0x2, 0x2, 0x4, 0x3e, 0x3, 0x2, 0x2, 0x2, 0x6, 0x4a, 
    0x3, 0x2, 0x2, 0x2, 0x8, 0x57, 0x3, 0x2, 0x2, 0x2, 0xa, 0x59, 0x3, 0x2, 
    0x2, 0x2, 0xc, 0x5b, 0x3, 0x2, 0x2, 0x2, 0xe, 0x64, 0x3, 0x2, 0x2, 0x2, 
    0x10, 0x66, 0x3, 0x2, 0x2, 0x2, 0x12, 0x79, 0x3, 0x2, 0x2, 0x2, 0x14, 
    0x7b, 0x3, 0x2, 0x2, 0x2, 0x16, 0x80, 0x3, 0x2, 0x2, 0x2, 0x18, 0x88, 
    0x3, 0x2, 0x2, 0x2, 0x1a, 0x95, 0x3, 0x2, 0x2, 0x2, 0x1c, 0x9b, 0x3, 
    0x2, 0x2, 0x2, 0x1e, 0xab, 0x3, 0x2, 0x2, 0x2, 0x20, 0xad, 0x3, 0x2, 
    0x2, 0x2, 0x22, 0xb9, 0x3, 0x2, 0x2, 0x2, 0x24, 0xc0, 0x3, 0x2, 0x2, 
    0x2, 0x26, 0xc8, 0x3, 0x2, 0x2, 0x2, 0x28, 0xcf, 0x3, 0x2, 0x2, 0x2, 
    0x2a, 0xd1, 0x3, 0x2, 0x2, 0x2, 0x2c, 0xd3, 0x3, 0x2, 0x2, 0x2, 0x2e, 
    0xdf, 0x3, 0x2, 0x2, 0x2, 0x30, 0xe1, 0x3, 0x2, 0x2, 0x2, 0x32, 0xed, 
    0x3, 0x2, 0x2, 0x2, 0x34, 0xf6, 0x3, 0x2, 0x2, 0x2, 0x36, 0xf8, 0x3, 
    0x2, 0x2, 0x2, 0x38, 0xff, 0x3, 0x2, 0x2, 0x2, 0x3a, 0x101, 0x3, 0x2, 
    0x2, 0x2, 0x3c, 0x3d, 0x5, 0x4, 0x3, 0x2, 0x3d, 0x3, 0x3, 0x2, 0x2, 
    0x2, 0x3e, 0x3f, 0x8, 0x3, 0x1, 0x2, 0x3f, 0x40, 0x5, 0x6, 0x4, 0x2, 
    0x40, 0x45, 0x3, 0x2, 0x2, 0x2, 0x41, 0x42, 0xc, 0x4, 0x2, 0x2, 0x42, 
    0x44, 0x5, 0x6, 0x4, 0x2, 0x43, 0x41, 0x3, 0x2, 0x2, 0x2, 0x44, 0x47, 
    0x3, 0x2, 0x2, 0x2, 0x45, 0x43, 0x3, 0x2, 0x2, 0x2, 0x45, 0x46, 0x3, 
    0x2, 0x2, 0x2, 0x46, 0x5, 0x3, 0x2, 0x2, 0x2, 0x47, 0x45, 0x3, 0x2, 
    0x2, 0x2, 0x48, 0x4b, 0x5, 0x8, 0x5, 0x2, 0x49, 0x4b, 0x5, 0xc, 0x7, 
    0x2, 0x4a, 0x48, 0x3, 0x2, 0x2, 0x2, 0x4a, 0x49, 0x3, 0x2, 0x2, 0x2, 
    0x4b, 0x7, 0x3, 0x2, 0x2, 0x2, 0x4c, 0x4d, 0x5, 0xa, 0x6, 0x2, 0x4d, 
    0x4e, 0x7, 0xc, 0x2, 0x2, 0x4e, 0x4f, 0x7, 0x1e, 0x2, 0x2, 0x4f, 0x58, 
    0x3, 0x2, 0x2, 0x2, 0x50, 0x51, 0x5, 0xa, 0x6, 0x2, 0x51, 0x52, 0x7, 
    0xc, 0x2, 0x2, 0x52, 0x53, 0x7, 0x1b, 0x2, 0x2, 0x53, 0x54, 0x7, 0xa, 
    0x2, 0x2, 0x54, 0x55, 0x7, 0x1c, 0x2, 0x2, 0x55, 0x56, 0x7, 0x1e, 0x2, 
    0x2, 0x56, 0x58, 0x3, 0x2, 0x2, 0x2, 0x57, 0x4c, 0x3, 0x2, 0x2, 0x2, 
    0x57, 0x50, 0x3, 0x2, 0x2, 0x2, 0x58, 0x9, 0x3, 0x2, 0x2, 0x2, 0x59, 
    0x5a, 0x9, 0x2, 0x2, 0x2, 0x5a, 0xb, 0x3, 0x2, 0x2, 0x2, 0x5b, 0x5c, 
    0x5, 0xa, 0x6, 0x2, 0x5c, 0x5d, 0x7, 0xc, 0x2, 0x2, 0x5d, 0x5e, 0x7, 
    0x17, 0x2, 0x2, 0x5e, 0x5f, 0x5, 0xe, 0x8, 0x2, 0x5f, 0x60, 0x7, 0x18, 
    0x2, 0x2, 0x60, 0x61, 0x5, 0x14, 0xb, 0x2, 0x61, 0xd, 0x3, 0x2, 0x2, 
    0x2, 0x62, 0x65, 0x5, 0x10, 0x9, 0x2, 0x63, 0x65, 0x7, 0x5, 0x2, 0x2, 
    0x64, 0x62, 0x3, 0x2, 0x2, 0x2, 0x64, 0x63, 0x3, 0x2, 0x2, 0x2, 0x65, 
    0xf, 0x3, 0x2, 0x2, 0x2, 0x66, 0x67, 0x8, 0x9, 0x1, 0x2, 0x67, 0x68, 
    0x5, 0x12, 0xa, 0x2, 0x68, 0x6e, 0x3, 0x2, 0x2, 0x2, 0x69, 0x6a, 0xc, 
    0x4, 0x2, 0x2, 0x6a, 0x6b, 0x7, 0x1d, 0x2, 0x2, 0x6b, 0x6d, 0x5, 0x12, 
    0xa, 0x2, 0x6c, 0x69, 0x3, 0x2, 0x2, 0x2, 0x6d, 0x70, 0x3, 0x2, 0x2, 
    0x2, 0x6e, 0x6c, 0x3, 0x2, 0x2, 0x2, 0x6e, 0x6f, 0x3, 0x2, 0x2, 0x2, 
    0x6f, 0x11, 0x3, 0x2, 0x2, 0x2, 0x70, 0x6e, 0x3, 0x2, 0x2, 0x2, 0x71, 
    0x72, 0x5, 0xa, 0x6, 0x2, 0x72, 0x73, 0x7, 0xc, 0x2, 0x2, 0x73, 0x7a, 
    0x3, 0x2, 0x2, 0x2, 0x74, 0x75, 0x5, 0xa, 0x6, 0x2, 0x75, 0x76, 0x7, 
    0xc, 0x2, 0x2, 0x76, 0x77, 0x7, 0x1b, 0x2, 0x2, 0x77, 0x78, 0x7, 0x1c, 
    0x2, 0x2, 0x78, 0x7a, 0x3, 0x2, 0x2, 0x2, 0x79, 0x71, 0x3, 0x2, 0x2, 
    0x2, 0x79, 0x74, 0x3, 0x2, 0x2, 0x2, 0x7a, 0x13, 0x3, 0x2, 0x2, 0x2, 
    0x7b, 0x7c, 0x7, 0x19, 0x2, 0x2, 0x7c, 0x7d, 0x5, 0x16, 0xc, 0x2, 0x7d, 
    0x7e, 0x5, 0x18, 0xd, 0x2, 0x7e, 0x7f, 0x7, 0x1a, 0x2, 0x2, 0x7f, 0x15, 
    0x3, 0x2, 0x2, 0x2, 0x80, 0x85, 0x8, 0xc, 0x1, 0x2, 0x81, 0x82, 0xc, 
    0x4, 0x2, 0x2, 0x82, 0x84, 0x5, 0x8, 0x5, 0x2, 0x83, 0x81, 0x3, 0x2, 
    0x2, 0x2, 0x84, 0x87, 0x3, 0x2, 0x2, 0x2, 0x85, 0x83, 0x3, 0x2, 0x2, 
    0x2, 0x85, 0x86, 0x3, 0x2, 0x2, 0x2, 0x86, 0x17, 0x3, 0x2, 0x2, 0x2, 
    0x87, 0x85, 0x3, 0x2, 0x2, 0x2, 0x88, 0x8d, 0x8, 0xd, 0x1, 0x2, 0x89, 
    0x8a, 0xc, 0x4, 0x2, 0x2, 0x8a, 0x8c, 0x5, 0x1a, 0xe, 0x2, 0x8b, 0x89, 
    0x3, 0x2, 0x2, 0x2, 0x8c, 0x8f, 0x3, 0x2, 0x2, 0x2, 0x8d, 0x8b, 0x3, 
    0x2, 0x2, 0x2, 0x8d, 0x8e, 0x3, 0x2, 0x2, 0x2, 0x8e, 0x19, 0x3, 0x2, 
    0x2, 0x2, 0x8f, 0x8d, 0x3, 0x2, 0x2, 0x2, 0x90, 0x96, 0x5, 0x1c, 0xf, 
    0x2, 0x91, 0x96, 0x5, 0x14, 0xb, 0x2, 0x92, 0x96, 0x5, 0x1e, 0x10, 0x2, 
    0x93, 0x96, 0x5, 0x20, 0x11, 0x2, 0x94, 0x96, 0x5, 0x22, 0x12, 0x2, 
    0x95, 0x90, 0x3, 0x2, 0x2, 0x2, 0x95, 0x91, 0x3, 0x2, 0x2, 0x2, 0x95, 
    0x92, 0x3, 0x2, 0x2, 0x2, 0x95, 0x93, 0x3, 0x2, 0x2, 0x2, 0x95, 0x94, 
    0x3, 0x2, 0x2, 0x2, 0x96, 0x1b, 0x3, 0x2, 0x2, 0x2, 0x97, 0x98, 0x5, 
    0x24, 0x13, 0x2, 0x98, 0x99, 0x7, 0x1e, 0x2, 0x2, 0x99, 0x9c, 0x3, 0x2, 
    0x2, 0x2, 0x9a, 0x9c, 0x7, 0x1e, 0x2, 0x2, 0x9b, 0x97, 0x3, 0x2, 0x2, 
    0x2, 0x9b, 0x9a, 0x3, 0x2, 0x2, 0x2, 0x9c, 0x1d, 0x3, 0x2, 0x2, 0x2, 
    0x9d, 0x9e, 0x7, 0x6, 0x2, 0x2, 0x9e, 0x9f, 0x7, 0x17, 0x2, 0x2, 0x9f, 
    0xa0, 0x5, 0x24, 0x13, 0x2, 0xa0, 0xa1, 0x7, 0x18, 0x2, 0x2, 0xa1, 0xa2, 
    0x5, 0x1a, 0xe, 0x2, 0xa2, 0xac, 0x3, 0x2, 0x2, 0x2, 0xa3, 0xa4, 0x7, 
    0x6, 0x2, 0x2, 0xa4, 0xa5, 0x7, 0x17, 0x2, 0x2, 0xa5, 0xa6, 0x5, 0x24, 
    0x13, 0x2, 0xa6, 0xa7, 0x7, 0x18, 0x2, 0x2, 0xa7, 0xa8, 0x5, 0x1a, 0xe, 
    0x2, 0xa8, 0xa9, 0x7, 0x7, 0x2, 0x2, 0xa9, 0xaa, 0x5, 0x1a, 0xe, 0x2, 
    0xaa, 0xac, 0x3, 0x2, 0x2, 0x2, 0xab, 0x9d, 0x3, 0x2, 0x2, 0x2, 0xab, 
    0xa3, 0x3, 0x2, 0x2, 0x2, 0xac, 0x1f, 0x3, 0x2, 0x2, 0x2, 0xad, 0xae, 
    0x7, 0x8, 0x2, 0x2, 0xae, 0xaf, 0x7, 0x17, 0x2, 0x2, 0xaf, 0xb0, 0x5, 
    0x24, 0x13, 0x2, 0xb0, 0xb1, 0x7, 0x18, 0x2, 0x2, 0xb1, 0xb2, 0x5, 0x1a, 
    0xe, 0x2, 0xb2, 0x21, 0x3, 0x2, 0x2, 0x2, 0xb3, 0xb4, 0x7, 0x9, 0x2, 
    0x2, 0xb4, 0xba, 0x7, 0x1e, 0x2, 0x2, 0xb5, 0xb6, 0x7, 0x9, 0x2, 0x2, 
    0xb6, 0xb7, 0x5, 0x24, 0x13, 0x2, 0xb7, 0xb8, 0x7, 0x1e, 0x2, 0x2, 0xb8, 
    0xba, 0x3, 0x2, 0x2, 0x2, 0xb9, 0xb3, 0x3, 0x2, 0x2, 0x2, 0xb9, 0xb5, 
    0x3, 0x2, 0x2, 0x2, 0xba, 0x23, 0x3, 0x2, 0x2, 0x2, 0xbb, 0xbc, 0x5, 
    0x26, 0x14, 0x2, 0xbc, 0xbd, 0x7, 0x10, 0x2, 0x2, 0xbd, 0xbe, 0x5, 0x24, 
    0x13, 0x2, 0xbe, 0xc1, 0x3, 0x2, 0x2, 0x2, 0xbf, 0xc1, 0x5, 0x28, 0x15, 
    0x2, 0xc0, 0xbb, 0x3, 0x2, 0x2, 0x2, 0xc0, 0xbf, 0x3, 0x2, 0x2, 0x2, 
    0xc1, 0x25, 0x3, 0x2, 0x2, 0x2, 0xc2, 0xc9, 0x7, 0xc, 0x2, 0x2, 0xc3, 
    0xc4, 0x7, 0xc, 0x2, 0x2, 0xc4, 0xc5, 0x7, 0x1b, 0x2, 0x2, 0xc5, 0xc6, 
    0x5, 0x24, 0x13, 0x2, 0xc6, 0xc7, 0x7, 0x1c, 0x2, 0x2, 0xc7, 0xc9, 0x3, 
    0x2, 0x2, 0x2, 0xc8, 0xc2, 0x3, 0x2, 0x2, 0x2, 0xc8, 0xc3, 0x3, 0x2, 
    0x2, 0x2, 0xc9, 0x27, 0x3, 0x2, 0x2, 0x2, 0xca, 0xcb, 0x5, 0x2c, 0x17, 
    0x2, 0xcb, 0xcc, 0x5, 0x2a, 0x16, 0x2, 0xcc, 0xcd, 0x5, 0x2c, 0x17, 
    0x2, 0xcd, 0xd0, 0x3, 0x2, 0x2, 0x2, 0xce, 0xd0, 0x5, 0x2c, 0x17, 0x2, 
    0xcf, 0xca, 0x3, 0x2, 0x2, 0x2, 0xcf, 0xce, 0x3, 0x2, 0x2, 0x2, 0xd0, 
    0x29, 0x3, 0x2, 0x2, 0x2, 0xd1, 0xd2, 0x9, 0x3, 0x2, 0x2, 0xd2, 0x2b, 
    0x3, 0x2, 0x2, 0x2, 0xd3, 0xd4, 0x8, 0x17, 0x1, 0x2, 0xd4, 0xd5, 0x5, 
    0x30, 0x19, 0x2, 0xd5, 0xdc, 0x3, 0x2, 0x2, 0x2, 0xd6, 0xd7, 0xc, 0x4, 
    0x2, 0x2, 0xd7, 0xd8, 0x5, 0x2e, 0x18, 0x2, 0xd8, 0xd9, 0x5, 0x30, 0x19, 
    0x2, 0xd9, 0xdb, 0x3, 0x2, 0x2, 0x2, 0xda, 0xd6, 0x3, 0x2, 0x2, 0x2, 
    0xdb, 0xde, 0x3, 0x2, 0x2, 0x2, 0xdc, 0xda, 0x3, 0x2, 0x2, 0x2, 0xdc, 
    0xdd, 0x3, 0x2, 0x2, 0x2, 0xdd, 0x2d, 0x3, 0x2, 0x2, 0x2, 0xde, 0xdc, 
    0x3, 0x2, 0x2, 0x2, 0xdf, 0xe0, 0x9, 0x4, 0x2, 0x2, 0xe0, 0x2f, 0x3, 
    0x2, 0x2, 0x2, 0xe1, 0xe2, 0x8, 0x19, 0x1, 0x2, 0xe2, 0xe3, 0x5, 0x34, 
    0x1b, 0x2, 0xe3, 0xea, 0x3, 0x2, 0x2, 0x2, 0xe4, 0xe5, 0xc, 0x4, 0x2, 
    0x2, 0xe5, 0xe6, 0x5, 0x32, 0x1a, 0x2, 0xe6, 0xe7, 0x5, 0x34, 0x1b, 
    0x2, 0xe7, 0xe9, 0x3, 0x2, 0x2, 0x2, 0xe8, 0xe4, 0x3, 0x2, 0x2, 0x2, 
    0xe9, 0xec, 0x3, 0x2, 0x2, 0x2, 0xea, 0xe8, 0x3, 0x2, 0x2, 0x2, 0xea, 
    0xeb, 0x3, 0x2, 0x2, 0x2, 0xeb, 0x31, 0x3, 0x2, 0x2, 0x2, 0xec, 0xea, 
    0x3, 0x2, 0x2, 0x2, 0xed, 0xee, 0x9, 0x5, 0x2, 0x2, 0xee, 0x33, 0x3, 
    0x2, 0x2, 0x2, 0xef, 0xf0, 0x7, 0x17, 0x2, 0x2, 0xf0, 0xf1, 0x5, 0x24, 
    0x13, 0x2, 0xf1, 0xf2, 0x7, 0x18, 0x2, 0x2, 0xf2, 0xf7, 0x3, 0x2, 0x2, 
    0x2, 0xf3, 0xf7, 0x5, 0x26, 0x14, 0x2, 0xf4, 0xf7, 0x5, 0x36, 0x1c, 
    0x2, 0xf5, 0xf7, 0x7, 0xa, 0x2, 0x2, 0xf6, 0xef, 0x3, 0x2, 0x2, 0x2, 
    0xf6, 0xf3, 0x3, 0x2, 0x2, 0x2, 0xf6, 0xf4, 0x3, 0x2, 0x2, 0x2, 0xf6, 
    0xf5, 0x3, 0x2, 0x2, 0x2, 0xf7, 0x35, 0x3, 0x2, 0x2, 0x2, 0xf8, 0xf9, 
    0x7, 0xc, 0x2, 0x2, 0xf9, 0xfa, 0x7, 0x17, 0x2, 0x2, 0xfa, 0xfb, 0x5, 
    0x38, 0x1d, 0x2, 0xfb, 0xfc, 0x7, 0x18, 0x2, 0x2, 0xfc, 0x37, 0x3, 0x2, 
    0x2, 0x2, 0xfd, 0x100, 0x5, 0x3a, 0x1e, 0x2, 0xfe, 0x100, 0x3, 0x2, 
    0x2, 0x2, 0xff, 0xfd, 0x3, 0x2, 0x2, 0x2, 0xff, 0xfe, 0x3, 0x2, 0x2, 
    0x2, 0x100, 0x39, 0x3, 0x2, 0x2, 0x2, 0x101, 0x102, 0x8, 0x1e, 0x1, 
    0x2, 0x102, 0x103, 0x5, 0x24, 0x13, 0x2, 0x103, 0x109, 0x3, 0x2, 0x2, 
    0x2, 0x104, 0x105, 0xc, 0x4, 0x2, 0x2, 0x105, 0x106, 0x7, 0x1d, 0x2, 
    0x2, 0x106, 0x108, 0x5, 0x24, 0x13, 0x2, 0x107, 0x104, 0x3, 0x2, 0x2, 
    0x2, 0x108, 0x10b, 0x3, 0x2, 0x2, 0x2, 0x109, 0x107, 0x3, 0x2, 0x2, 
    0x2, 0x109, 0x10a, 0x3, 0x2, 0x2, 0x2, 0x10a, 0x3b, 0x3, 0x2, 0x2, 0x2, 
    0x10b, 0x109, 0x3, 0x2, 0x2, 0x2, 0x16, 0x45, 0x4a, 0x57, 0x64, 0x6e, 
    0x79, 0x85, 0x8d, 0x95, 0x9b, 0xab, 0xb9, 0xc0, 0xc8, 0xcf, 0xdc, 0xea, 
    0xf6, 0xff, 0x109, 
  };

  atn::ATNDeserializer deserializer;
  _atn = deserializer.deserialize(_serializedATN);

  size_t count = _atn.getNumberOfDecisions();
  _decisionToDFA.reserve(count);
  for (size_t i = 0; i < count; i++) { 
    _decisionToDFA.emplace_back(_atn.getDecisionState(i), i);
  }
}

TParser::Initializer TParser::_init;
