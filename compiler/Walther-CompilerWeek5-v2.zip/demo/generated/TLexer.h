/* lexer header section */

// Generated from D:/workspace/CompilerDesign/compiler/grammar/TLexer.g4 by ANTLR 4.7.1

#pragma once

/* lexer precinclude section */

#include "antlr4-runtime.h"


/* lexer postinclude section */
#ifndef _WIN32
#pragma GCC diagnostic ignored "-Wunused-parameter"
#endif


namespace antlrcpptest {

/* lexer context section */

class  TLexer : public antlr4::Lexer {
public:
  enum {
    DUMMY = 1, INT_KEYWORD = 2, VOID_KEYWORD = 3, IF_KEYWORD = 4, ELSE_KEYWORD = 5, 
    WHILE_KEYWORD = 6, RETURN_KEYWORD = 7, NUM = 8, DIGIT = 9, ID = 10, 
    LETTER = 11, COMMENT = 12, WS = 13, ASSIGN = 14, PLUS = 15, MINUS = 16, 
    MULTIPLY = 17, DIVIDE = 18, LESS_THAN = 19, GREATER_THAN = 20, LEFT_PAREN = 21, 
    RIGHT_PAREN = 22, LEFT_BRACES = 23, RIGHT_BRACES = 24, LEFT_BRACKET = 25, 
    RIGHT_BRACKET = 26, COMMA = 27, SEMICOLON = 28, LESS_THAN_OR_EQUAL = 29, 
    GREATER_THAN_OR_EQUAL = 30, EQUALITY = 31, NON_EQUALITY = 32
  };

  enum {
    CommentsChannel = 2, DirectiveChannel = 3
  };

  TLexer(antlr4::CharStream *input);
  ~TLexer();

  /* public lexer declarations section */
  bool canTestFoo() { return true; }
  bool isItFoo() { return true; }
  bool isItBar() { return true; }

  void myFooLexerAction() { /* do something*/ };
  void myBarLexerAction() { /* do something*/ };

  virtual std::string getGrammarFileName() const override;
  virtual const std::vector<std::string>& getRuleNames() const override;

  virtual const std::vector<std::string>& getChannelNames() const override;
  virtual const std::vector<std::string>& getModeNames() const override;
  virtual const std::vector<std::string>& getTokenNames() const override; // deprecated, use vocabulary instead
  virtual antlr4::dfa::Vocabulary& getVocabulary() const override;

  virtual const std::vector<uint16_t> getSerializedATN() const override;
  virtual const antlr4::atn::ATN& getATN() const override;

private:
  static std::vector<antlr4::dfa::DFA> _decisionToDFA;
  static antlr4::atn::PredictionContextCache _sharedContextCache;
  static std::vector<std::string> _ruleNames;
  static std::vector<std::string> _tokenNames;
  static std::vector<std::string> _channelNames;
  static std::vector<std::string> _modeNames;

  static std::vector<std::string> _literalNames;
  static std::vector<std::string> _symbolicNames;
  static antlr4::dfa::Vocabulary _vocabulary;
  static antlr4::atn::ATN _atn;
  static std::vector<uint16_t> _serializedATN;

  /* private lexer declarations/members section */

  // Individual action functions triggered by action() above.

  // Individual semantic predicate functions triggered by sempred() above.

  struct Initializer {
    Initializer();
  };
  static Initializer _init;
};

}  // namespace antlrcpptest
