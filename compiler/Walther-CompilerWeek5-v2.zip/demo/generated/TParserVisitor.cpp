/* parser/listener/visitor header section */

// Generated from D:/workspace/CompilerDesign/compiler/grammar/TParser.g4 by ANTLR 4.7.1

/* visitor preinclude section */

#include "TParserVisitor.h"

/* visitor postinclude section */

using namespace antlrcpptest;

/* visitor definitions section */
