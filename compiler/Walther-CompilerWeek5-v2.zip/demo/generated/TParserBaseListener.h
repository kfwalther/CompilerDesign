/* parser/listener/visitor header section */

// Generated from D:/workspace/CompilerDesign/compiler/grammar/TParser.g4 by ANTLR 4.7.1

#pragma once

/* base listener preinclude section */

#include "antlr4-runtime.h"
#include "TParserListener.h"

/* base listener postinclude section */

namespace antlrcpptest {

/**
 * This class provides an empty implementation of TParserListener,
 * which can be extended to create a listener which only needs to handle a subset
 * of the available methods.
 */
class  TParserBaseListener : public TParserListener {
public:
/* base listener public declarations/members section */

  virtual void enterProgram(TParser::ProgramContext * /*ctx*/) override { }
  virtual void exitProgram(TParser::ProgramContext * /*ctx*/) override { }

  virtual void enterDeclarationList(TParser::DeclarationListContext * /*ctx*/) override { }
  virtual void exitDeclarationList(TParser::DeclarationListContext * /*ctx*/) override { }

  virtual void enterDeclaration(TParser::DeclarationContext * /*ctx*/) override { }
  virtual void exitDeclaration(TParser::DeclarationContext * /*ctx*/) override { }

  virtual void enterVarDeclaration(TParser::VarDeclarationContext * /*ctx*/) override { }
  virtual void exitVarDeclaration(TParser::VarDeclarationContext * /*ctx*/) override { }

  virtual void enterTypeSpecifier(TParser::TypeSpecifierContext * /*ctx*/) override { }
  virtual void exitTypeSpecifier(TParser::TypeSpecifierContext * /*ctx*/) override { }

  virtual void enterFunDeclaration(TParser::FunDeclarationContext * /*ctx*/) override { }
  virtual void exitFunDeclaration(TParser::FunDeclarationContext * /*ctx*/) override { }

  virtual void enterParams(TParser::ParamsContext * /*ctx*/) override { }
  virtual void exitParams(TParser::ParamsContext * /*ctx*/) override { }

  virtual void enterParamList(TParser::ParamListContext * /*ctx*/) override { }
  virtual void exitParamList(TParser::ParamListContext * /*ctx*/) override { }

  virtual void enterParam(TParser::ParamContext * /*ctx*/) override { }
  virtual void exitParam(TParser::ParamContext * /*ctx*/) override { }

  virtual void enterCompoundStmt(TParser::CompoundStmtContext * /*ctx*/) override { }
  virtual void exitCompoundStmt(TParser::CompoundStmtContext * /*ctx*/) override { }

  virtual void enterLocalDeclaration(TParser::LocalDeclarationContext * /*ctx*/) override { }
  virtual void exitLocalDeclaration(TParser::LocalDeclarationContext * /*ctx*/) override { }

  virtual void enterStatementList(TParser::StatementListContext * /*ctx*/) override { }
  virtual void exitStatementList(TParser::StatementListContext * /*ctx*/) override { }

  virtual void enterStatement(TParser::StatementContext * /*ctx*/) override { }
  virtual void exitStatement(TParser::StatementContext * /*ctx*/) override { }

  virtual void enterExpressionStmt(TParser::ExpressionStmtContext * /*ctx*/) override { }
  virtual void exitExpressionStmt(TParser::ExpressionStmtContext * /*ctx*/) override { }

  virtual void enterSelectionStmt(TParser::SelectionStmtContext * /*ctx*/) override { }
  virtual void exitSelectionStmt(TParser::SelectionStmtContext * /*ctx*/) override { }

  virtual void enterIterationStmt(TParser::IterationStmtContext * /*ctx*/) override { }
  virtual void exitIterationStmt(TParser::IterationStmtContext * /*ctx*/) override { }

  virtual void enterReturnStmt(TParser::ReturnStmtContext * /*ctx*/) override { }
  virtual void exitReturnStmt(TParser::ReturnStmtContext * /*ctx*/) override { }

  virtual void enterExpression(TParser::ExpressionContext * /*ctx*/) override { }
  virtual void exitExpression(TParser::ExpressionContext * /*ctx*/) override { }

  virtual void enterVar(TParser::VarContext * /*ctx*/) override { }
  virtual void exitVar(TParser::VarContext * /*ctx*/) override { }

  virtual void enterSimpleExpression(TParser::SimpleExpressionContext * /*ctx*/) override { }
  virtual void exitSimpleExpression(TParser::SimpleExpressionContext * /*ctx*/) override { }

  virtual void enterRelop(TParser::RelopContext * /*ctx*/) override { }
  virtual void exitRelop(TParser::RelopContext * /*ctx*/) override { }

  virtual void enterAdditiveExpression(TParser::AdditiveExpressionContext * /*ctx*/) override { }
  virtual void exitAdditiveExpression(TParser::AdditiveExpressionContext * /*ctx*/) override { }

  virtual void enterAddop(TParser::AddopContext * /*ctx*/) override { }
  virtual void exitAddop(TParser::AddopContext * /*ctx*/) override { }

  virtual void enterTerm(TParser::TermContext * /*ctx*/) override { }
  virtual void exitTerm(TParser::TermContext * /*ctx*/) override { }

  virtual void enterMulop(TParser::MulopContext * /*ctx*/) override { }
  virtual void exitMulop(TParser::MulopContext * /*ctx*/) override { }

  virtual void enterFactor(TParser::FactorContext * /*ctx*/) override { }
  virtual void exitFactor(TParser::FactorContext * /*ctx*/) override { }

  virtual void enterCall(TParser::CallContext * /*ctx*/) override { }
  virtual void exitCall(TParser::CallContext * /*ctx*/) override { }

  virtual void enterArgs(TParser::ArgsContext * /*ctx*/) override { }
  virtual void exitArgs(TParser::ArgsContext * /*ctx*/) override { }

  virtual void enterArgList(TParser::ArgListContext * /*ctx*/) override { }
  virtual void exitArgList(TParser::ArgListContext * /*ctx*/) override { }


  virtual void enterEveryRule(antlr4::ParserRuleContext * /*ctx*/) override { }
  virtual void exitEveryRule(antlr4::ParserRuleContext * /*ctx*/) override { }
  virtual void visitTerminal(antlr4::tree::TerminalNode * /*node*/) override { }
  virtual void visitErrorNode(antlr4::tree::ErrorNode * /*node*/) override { }

private:  
/* base listener private declarations/members section */
};

}  // namespace antlrcpptest
