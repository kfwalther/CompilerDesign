/* parser/listener/visitor header section */

// Generated from D:/workspace/CompilerDesign/compiler/grammar/TParser.g4 by ANTLR 4.7.1

#pragma once

/* visitor preinclude section */

#include "antlr4-runtime.h"
#include "TParser.h"

/* visitor postinclude section */

namespace antlrcpptest {

/**
 * This class defines an abstract visitor for a parse tree
 * produced by TParser.
 */
class  TParserVisitor : public antlr4::tree::AbstractParseTreeVisitor {
public:
  /* visitor public declarations/members section */

  /**
   * Visit parse trees produced by TParser.
   */
    virtual antlrcpp::Any visitProgram(TParser::ProgramContext *context) = 0;

    virtual antlrcpp::Any visitDeclarationList(TParser::DeclarationListContext *context) = 0;

    virtual antlrcpp::Any visitDeclaration(TParser::DeclarationContext *context) = 0;

    virtual antlrcpp::Any visitVarDeclaration(TParser::VarDeclarationContext *context) = 0;

    virtual antlrcpp::Any visitTypeSpecifier(TParser::TypeSpecifierContext *context) = 0;

    virtual antlrcpp::Any visitFunDeclaration(TParser::FunDeclarationContext *context) = 0;

    virtual antlrcpp::Any visitParams(TParser::ParamsContext *context) = 0;

    virtual antlrcpp::Any visitParamList(TParser::ParamListContext *context) = 0;

    virtual antlrcpp::Any visitParam(TParser::ParamContext *context) = 0;

    virtual antlrcpp::Any visitCompoundStmt(TParser::CompoundStmtContext *context) = 0;

    virtual antlrcpp::Any visitLocalDeclaration(TParser::LocalDeclarationContext *context) = 0;

    virtual antlrcpp::Any visitStatementList(TParser::StatementListContext *context) = 0;

    virtual antlrcpp::Any visitStatement(TParser::StatementContext *context) = 0;

    virtual antlrcpp::Any visitExpressionStmt(TParser::ExpressionStmtContext *context) = 0;

    virtual antlrcpp::Any visitSelectionStmt(TParser::SelectionStmtContext *context) = 0;

    virtual antlrcpp::Any visitIterationStmt(TParser::IterationStmtContext *context) = 0;

    virtual antlrcpp::Any visitReturnStmt(TParser::ReturnStmtContext *context) = 0;

    virtual antlrcpp::Any visitExpression(TParser::ExpressionContext *context) = 0;

    virtual antlrcpp::Any visitVar(TParser::VarContext *context) = 0;

    virtual antlrcpp::Any visitSimpleExpression(TParser::SimpleExpressionContext *context) = 0;

    virtual antlrcpp::Any visitRelop(TParser::RelopContext *context) = 0;

    virtual antlrcpp::Any visitAdditiveExpression(TParser::AdditiveExpressionContext *context) = 0;

    virtual antlrcpp::Any visitAddop(TParser::AddopContext *context) = 0;

    virtual antlrcpp::Any visitTerm(TParser::TermContext *context) = 0;

    virtual antlrcpp::Any visitMulop(TParser::MulopContext *context) = 0;

    virtual antlrcpp::Any visitFactor(TParser::FactorContext *context) = 0;

    virtual antlrcpp::Any visitCall(TParser::CallContext *context) = 0;

    virtual antlrcpp::Any visitArgs(TParser::ArgsContext *context) = 0;

    virtual antlrcpp::Any visitArgList(TParser::ArgListContext *context) = 0;


private:  
/* visitor private declarations/members section */
};

}  // namespace antlrcpptest
