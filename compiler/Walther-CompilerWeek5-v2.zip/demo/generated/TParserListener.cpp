/* parser/listener/visitor header section */

// Generated from D:/workspace/CompilerDesign/compiler/grammar/TParser.g4 by ANTLR 4.7.1

/* listener preinclude section */

#include "TParserListener.h"

/* listener postinclude section */

using namespace antlrcpptest;

/* listener definitions section */