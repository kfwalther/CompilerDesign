/* parser/listener/visitor header section */

// Generated from D:/workspace/CompilerDesign/compiler/grammar/TParser.g4 by ANTLR 4.7.1

/* base visitor preinclude section */

#include "TParserBaseVisitor.h"

/* base visitor postinclude section */

using namespace antlrcpptest;

/* base visitor definitions section */
